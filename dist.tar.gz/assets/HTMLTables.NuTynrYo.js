import{j as e,H as a}from"./index.D-o3K8gs.js";import s from"./CodeBlock.9M43XyIu.js";import"./mode-html.jZYdjdYr.js";import"./mode-css.Bol8x519.js";import{T as l}from"./table.BhpzimaC.js";import{c as t}from"./createLucideIcon.DN2HPS2i.js";import{P as o}from"./panels-top-left.CnfYQ8yY.js";import{I as r}from"./info.B4tio1YM.js";import"./ext-beautify.DLsk9G3U.js";import"./CopyButton.q9lS4ju6.js";/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const n=t("AlignJustify",[["path",{d:"M3 12h18",key:"1i2n21"}],["path",{d:"M3 18h18",key:"1h113x"}],["path",{d:"M3 6h18",key:"d0wm0j"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const d=t("Columns2",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M12 3v18",key:"108xh3"}]]),w=()=>e.jsxs("div",{className:"container p-8 mb-24",children:[e.jsxs(a,{children:[e.jsx("title",{children:"Tables in HTML | Help Code It"}),e.jsx("meta",{name:"description",content:"Learn how to create tables in HTML to display data in an organized grid-like format. HTML tables are used to arrange data in rows and columns."}),e.jsx("meta",{property:"og:title",content:"Tables in HTML | Help Code It"}),e.jsx("meta",{name:"keywords",content:"HTML Tables, HTML Table Structure, HTML Table Headers, HTML Table Styling, HTML Table Best Practices"}),e.jsx("meta",{canonical:"https://www.helpcodeit.com/htmlPages/Tables"})]}),e.jsx("h1",{className:"mb-4 text-5xl font-bold",children:"Understanding Tables in HTML"}),e.jsx("p",{className:"mb-6",children:"Tables are a powerful way to display data in an organized grid-like format. HTML provides a straightforward way to create tables to arrange data in rows and columns."}),e.jsxs("section",{className:"mb-8",children:[e.jsxs("h2",{className:"flex items-center mb-2 text-2xl font-semibold",children:[e.jsx(l,{className:"mr-2"})," Basic Table Structure"]}),e.jsxs("p",{className:"mb-4",children:["A basic HTML table is created using the ",e.jsx("code",{className:"border-none shadow-none",children:"<table>"})," element. Inside it, you define rows with the ",e.jsx("code",{className:"border-none shadow-none",children:"<tr>"})," element, and within each row, you add cells using the",e.jsx("code",{className:"border-none shadow-none",children:"<td>"})," element. Here’s an example:"]}),e.jsx(s,{code:`<table>
  <tr>
    <td>Row 1, Cell 1</td>
    <td>Row 1, Cell 2</td>
  </tr>
  <tr>
    <td>Row 2, Cell 1</td>
    <td>Row 2, Cell 2</td>
  </tr>
</table>`,language:"html"})]}),e.jsxs("section",{className:"mb-8",children:[e.jsxs("h2",{className:"flex items-center mb-2 text-2xl font-semibold",children:[e.jsx(d,{className:"mr-2"})," Adding Table Headers"]}),e.jsxs("p",{className:"mb-4",children:["To add headers to your table, use the ",e.jsx("code",{className:"border-none shadow-none",children:"<th>"})," element inside your rows. This typically goes in the first row to label each column:"]}),e.jsx(s,{code:`<table>
  <tr>
    <th>Header 1</th>
    <th>Header 2</th>
  </tr>
  <tr>
    <td>Row 1, Cell 1</td>
    <td>Row 1, Cell 2</td>
  </tr>
  <tr>
    <td>Row 2, Cell 1</td>
    <td>Row 2, Cell 2</td>
  </tr>
</table>`,language:"html"})]}),e.jsxs("section",{className:"mb-8",children:[e.jsxs("h2",{className:"flex items-center mb-2 text-2xl font-semibold",children:[e.jsx(n,{className:"mr-2"})," Merging Cells"]}),e.jsxs("p",{className:"mb-4",children:["Sometimes you might need to merge cells across columns or rows. This is done using the",e.jsx("code",{className:"border-none shadow-none",children:"colspan"})," or ",e.jsx("code",{className:"border-none shadow-none",children:"rowspan"})," attributes. For example, merging two columns:"]}),e.jsx(s,{code:`<table>
  <tr>
    <th colspan="2">Merged Header</th>
  </tr>
  <tr>
    <td>Row 1, Cell 1</td>
    <td>Row 1, Cell 2</td>
  </tr>
  <tr>
    <td colspan="2">Row 2, Merged Cells</td>
  </tr>
</table>`,language:"html"})]}),e.jsxs("section",{className:"mb-8",children:[e.jsxs("h2",{className:"flex items-center mb-2 text-2xl font-semibold",children:[e.jsx(o,{className:"mr-2"})," Styling Tables"]}),e.jsx("p",{className:"mb-4",children:"Tables can be styled using CSS to improve their appearance. You can add borders, adjust padding, and align text to make your tables more readable:"}),e.jsx(s,{code:`table {
  width: 100%;
  border-collapse: collapse;
}
th, td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}`,language:"css"})]}),e.jsxs("section",{children:[e.jsxs("h2",{className:"flex items-center mb-2 text-2xl font-semibold",children:[e.jsx(r,{className:"mr-2"})," Best Practices for Using Tables"]}),e.jsxs("ul",{className:"ml-6 list-disc",children:[e.jsxs("li",{className:"mb-2",children:[e.jsx("strong",{children:"Use Tables for Tabular Data"}),": Tables should be used to display structured data. Avoid using tables for layout purposes."]}),e.jsxs("li",{className:"mb-2",children:[e.jsx("strong",{children:"Keep Tables Simple"}),": Complex tables with too many rows and columns can be difficult to read. Break down large tables where possible."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Ensure Accessibility"}),": Use ",e.jsx("code",{className:"border-none shadow-none",children:"<th>"})," for headers and consider adding ",e.jsx("code",{className:"border-none shadow-none",children:"scope"})," attributes for better accessibility."]})]})]})]});export{w as default};
