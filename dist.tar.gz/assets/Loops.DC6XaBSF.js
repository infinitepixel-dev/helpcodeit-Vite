import{r as t,o as i,j as e,H as n,L as r,p as l}from"./index.DwCBaEMN.js";import o from"./CodeBlock.B6rFrndf.js";import"./ext-beautify.DLUgTP1-.js";import"./CopyButton.X1VqFWC_.js";const c="/assets/forloop.aBWM0YDI.svg",d="data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%2024%2024'%20fill='none'%20stroke='white'%20stroke-width='3'%20stroke-linecap='round'%20stroke-linejoin='round'%20class='feather%20feather-refresh-cw'%3e%3cpolyline%20points='23%204%2023%2010%2017%2010'%3e%3c/polyline%3e%3cpolyline%20points='1%2020%201%2014%207%2014'%3e%3c/polyline%3e%3cpath%20d='M3.51%209a9%209%200%200%201%2014.85-3.36L23%2010M1%2014l4.64%204.36A9%209%200%200%200%2020.49%2015'%3e%3c/path%3e%3c/svg%3e",h="data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%2024%2024'%20fill='none'%20stroke='black'%20stroke-width='3'%20stroke-linecap='round'%20stroke-linejoin='round'%20class='feather%20feather-refresh-cw'%3e%3cpolyline%20points='23%204%2023%2010%2017%2010'%3e%3c/polyline%3e%3cpolyline%20points='1%2020%201%2014%207%2014'%3e%3c/polyline%3e%3cpath%20d='M3.51%209a9%209%200%200%201%2014.85-3.36L23%2010M1%2014l4.64%204.36A9%209%200%200%200%2020.49%2015'%3e%3c/path%3e%3c/svg%3e",p="/assets/whichLoop.BxIz0rpE.svg",m="/assets/whileDoWhile.CQrYwvpq.png";function y(){const s=t.useRef(null);t.useEffect(()=>{i.to(s.current,{rotation:360,duration:4,repeat:-1,ease:"linear"})},[]);let a=window.matchMedia("(prefers-color-scheme: dark)").matches;return e.jsxs("div",{className:"container px-4 py-8 pb-40 mx-auto",children:[e.jsxs(n,{children:[e.jsx("title",{children:"JavaScript Loops | Help Code It"}),e.jsx("meta",{name:"description",content:"Learn about different types of loops in JavaScript including for loops, while loops, and do...while loops. Understand their use cases with practical examples."}),e.jsx("link",{rel:"canonical",href:"https://www.helpcodeit.com/javascriptPrincipals/Loops"}),e.jsx("meta",{name:"robots",content:"index, follow"}),e.jsx("meta",{name:"keywords",content:"JavaScript loops, for loop, while loop, do...while loop, coding tutorial, JavaScript tutorial, web development"})]}),e.jsxs("h1",{className:"mb-8 text-4xl font-bold text-center sm:text-6xl md:text-7xl",children:["Loops..."," ",e.jsx("span",{className:"text-3xl sm:text-5xl",children:"in JavaScript"}),e.jsx("img",{src:a?d:h,alt:"Reload Image",ref:s,className:"inline ml-2 animate-spin-slow h-14 w-14"})]}),e.jsx("hr",{className:"mb-10 border-black dark:border-white"}),e.jsx("div",{className:"p-4 mx-auto mb-8 bg-gray-100 border border-gray-300 rounded-lg shadow-lg w-fit dark:border-gray-500 dark:bg-gray-800",children:e.jsx("p",{className:"text-4xl text-center satisfyFont",children:"Loops are a programmer's best friend, helping us avoid repetitive code and making our lives easier!"})}),e.jsxs("section",{className:"mb-8",children:[e.jsx("h2",{className:"mb-4 text-3xl font-semibold",children:"What are Loops?"}),e.jsx("p",{className:"mb-4 text-lg",children:"Loops are a way to repeat a block of code multiple times. They are useful when you want to perform the same task multiple times, or when you want to iterate through a list of items."}),e.jsx("p",{className:"text-lg",children:"Let's explore the different types of loops in JavaScript and see how they can make our coding lives easier."})]}),e.jsx("hr",{className:"my-5 border-black dark:border-white"}),e.jsxs("section",{className:"mb-8",children:[e.jsx("h2",{className:"mb-4 text-3xl font-semibold",children:"For Loop"}),e.jsx("p",{className:"mb-4 text-lg",children:"The for loop is the most commonly used loop in JavaScript. It repeats a block of code a specified number of times. It's particularly useful when you know in advance how many times you want to execute a block of code."}),e.jsx(o,{code:`// Example 1: Counting from 1 to 5
for (let i = 1; i <= 5; i++) {
  console.log(i);
  // Output: 1, 2, 3, 4, 5
}

// Example 2: Summing numbers from 1 to 5
let sum = 0;

for (let i = 1; i <= 5; i++) {
  sum += i;
}

console.log("Sum:", sum);
// Output: Sum: 15

// Example 3: Iterating over an array
const fruits = ["apple", "banana", "cherry"];

for (let i = 0; i < fruits.length; i++) {
  console.log(fruits[i]);
  // Output: apple, banana, cherry
}`,language:"javascript"}),e.jsxs("div",{className:"mt-4 text-lg",children:[e.jsxs("p",{children:[e.jsx("strong",{children:"How it works:"})," The for loop has three parts:"]}),e.jsxs("ol",{className:"pl-6 list-decimal",children:[e.jsxs("li",{children:["Initialization: Where you set the starting value (e.g., ",e.jsx("i",{children:"let i = 1"}),")"]}),e.jsxs("li",{children:["Condition: The loop continues as long as this condition is true (e.g., ",e.jsx("i",{children:"i <= 5"}),")"]}),e.jsxs("li",{children:["Final expression: What happens after each iteration (e.g., ",e.jsx("i",{children:"i++"})," to increment i by 1)"]})]}),e.jsx("img",{src:c,alt:"For Loop",className:"w-2/5 p-12 mx-auto my-5 border border-gray-500 shadow-lg bg-slate-400 rounded-2xl"}),e.jsx("p",{className:"mt-4",children:e.jsx("strong",{children:"Example explanations:"})}),e.jsxs("ul",{className:"pl-6 list-disc",children:[e.jsx("li",{children:"Example 1 shows a simple count from 1 to 5."}),e.jsx("li",{children:"Example 2 demonstrates how to use a for loop to calculate a sum."}),e.jsx("li",{children:"Example 3 shows how to iterate over an array, a very common use case for for loops."})]})]})]}),e.jsx("hr",{className:"my-5 border-black dark:border-white"}),e.jsxs("section",{className:"mb-8",children:[e.jsx("h2",{className:"mb-4 text-3xl font-semibold",children:"While Loop"}),e.jsx("p",{className:"mb-4 text-lg",children:"The while loop repeats a block of code as long as a specified condition is true. This is useful when you don't know in advance how many times you need to run the loop."}),e.jsx(o,{code:`// Example 1: Counting down from 5 to 1
let count = 5;

while (count > 0) {
  console.log(count);
  // Output: 5, 4, 3, 2, 1

  count--;
}

// Example 2: Rolling a die until we get a 6
let dieRoll = 0; // Initialize dieRoll to 0
let attempts = 0; // attempts start at 0

while (dieRoll !== 6) {
  attempts++; // Increment attempts by 1

  dieRoll = Math.floor(Math.random() * 6) + 1;

  console.log("Rolled:", dieRoll);
  // Output: Rolled: 3, Rolled: 1, Rolled: 4, etc...
}

console.log("It took", attempts, "attempts to roll a 6");
// Output: It took 5 attempts to roll a 6

// Example 3: Input validation
let userInput;

while (isNaN(userInput)) {
  userInput = prompt("Please enter a number:");
}

console.log("You entered the number:", userInput);
// Output: You entered the number: 42`,language:"javascript"}),e.jsxs("div",{className:"mt-4 text-lg",children:[e.jsxs("p",{children:[e.jsx("strong",{children:"How it works:"})," The while loop has one main part:"]}),e.jsx("ul",{className:"pl-6 list-disc",children:e.jsx("li",{children:"Condition: The loop continues as long as this condition is true"})}),e.jsx("p",{children:"The loop will keep executing as long as the condition remains true. You need to make sure that the condition will eventually become false, or you'll create an infinite loop!"}),e.jsx("p",{className:"mt-4",children:e.jsx("strong",{children:"Example explanations:"})}),e.jsxs("ul",{className:"pl-6 list-disc",children:[e.jsx("li",{children:"Example 1 shows a countdown from 5 to 1."}),e.jsx("li",{children:"Example 2 simulates rolling a die until we get a 6. This is a good example of when we don't know how many iterations we'll need."}),e.jsx("li",{children:"Example 3 demonstrates input validation, continuing to ask for input until a valid number is entered."})]})]})]}),e.jsx("hr",{className:"my-5 border-black dark:border-white"}),e.jsx("div",{children:e.jsx("img",{src:m,alt:"Which to use While or Do While",className:"p-2 mx-auto my-10 bg-gray-200 border border-gray-500 rounded-lg shadow-lg h-96 "})}),e.jsx("hr",{className:"my-5 border-black dark:border-white"}),e.jsxs("section",{className:"mb-8",children:[e.jsx("h2",{className:"mb-4 text-3xl font-semibold",children:"Do...While Loop"}),e.jsx("p",{className:"mb-4 text-lg",children:"The do...while loop is similar to the while loop, but it always executes the code block at least once before checking the condition. This is useful when you want to ensure that your code runs at least once, regardless of the condition."}),e.jsx(o,{code:`// Example 1: Ensuring at least one execution
let i = 10;

do {
  console.log(i);
  // Output: 10 (loop body executes once even though condition is false)

  i++;
} while (i < 5);

// Example 2: Menu-driven program
let choice;

do {
  console.log("1. Play Game");
  console.log("2. View High Scores");
  console.log("3. Exit");

  choice = prompt("Enter your choice (1-3):");

  //Based on the choice, perform the corresponding action ie. 1,2,3
  switch (choice) {
    case "1":
      console.log("Starting game...");
      break;
    case "2":
      console.log("Displaying high scores...");
      break;
    case "3":
      console.log("Exiting...");
      break;
    default:
      console.log("Invalid choice. Try again.");
  }
} while (choice !== "3");

// Example 3: Password validation
let password;

do {
  password = prompt("Enter a password (at least 8 characters):");
} while (password.length < 8);

console.log("Password accepted!");
// Output: Password accepted!`,language:"javascript"}),e.jsxs("div",{className:"mt-4 text-lg",children:[e.jsxs("p",{children:[e.jsx("strong",{children:"How it works:"})," The do...while loop has two main parts:"]}),e.jsxs("ol",{className:"pl-6 list-decimal",children:[e.jsx("li",{children:"Do: The block of code to be executed"}),e.jsx("li",{children:"While: The condition that, if true, will make the loop continue"})]}),e.jsx("p",{children:"The key difference from a while loop is that a do...while loop will always execute its code block at least once, even if the condition is false from the start."}),e.jsx("p",{className:"mt-4",children:e.jsx("strong",{children:"Example explanations:"})}),e.jsxs("ul",{className:"pl-6 list-disc",children:[e.jsx("li",{children:"Example 1 demonstrates that the loop body executes once even when the condition is false from the start."}),e.jsx("li",{children:"Example 2 shows a menu-driven program, a common use case for do...while loops. It ensures the menu is displayed at least once."}),e.jsx("li",{children:"Example 3 illustrates password validation, continually prompting for a password until a valid one is entered."})]})]})]}),e.jsx("div",{className:"bg-red-400 rounded-md"}),e.jsx("hr",{className:"my-5 border-black dark:border-white"}),e.jsxs("section",{className:"mb-8",children:[e.jsx("img",{src:p,alt:"Which loop should I use graphic",className:"p-12 mx-auto my-5 border border-gray-500 shadow-lg w-fit bg-slate-300 rounded-2xl"}),e.jsxs("ul",{className:"pl-6 text-lg list-disc",children:[e.jsxs("li",{className:"mb-2",children:["Use a ",e.jsx("strong",{children:"for loop"})," when you know exactly how many times you want to run the loop, like iterating through an array or performing an action a specific number of times."]}),e.jsxs("li",{className:"mb-2",children:["Use a ",e.jsx("strong",{children:"while loop"})," when you don't know how many times you want to run the loop, but you know the condition under which it should stop. For example, when waiting for user input or when a certain condition is met."]}),e.jsxs("li",{className:"mb-2",children:["Use a ",e.jsx("strong",{children:"do...while loop"})," when you want to run the loop at least once, even if the condition is false from the start. This is useful for menu systems or input validation where you always want to perform an action before checking a condition."]})]})]}),e.jsx("div",{className:"m-10 text-center",children:e.jsx(r,{to:"/javascriptPrincipals/PracticeProblems",className:"px-4 py-2 m-4 font-bold text-white bg-blue-500 rounded hover:bg-blue-700",children:"Ready for Some Practice Problems?"})})]})}o.propTypes={code:l.string,language:l.string};export{y as default};
