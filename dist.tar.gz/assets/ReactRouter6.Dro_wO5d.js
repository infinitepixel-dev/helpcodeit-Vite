import{r as a,j as e,H as s}from"./index.DwCBaEMN.js";import{H as n}from"./index.C481uaJj.js";/* empty css                      */const i="data:image/svg+xml,%3c?xml%20version='1.0'%20encoding='UTF-8'?%3e%3csvg%20width='256px'%20height='140px'%20viewBox='0%200%20256%20140'%20version='1.1'%20xmlns='http://www.w3.org/2000/svg'%20xmlns:xlink='http://www.w3.org/1999/xlink'%20preserveAspectRatio='xMidYMid'%3e%3cg%3e%3cpath%20d='M78.0659341,92.5875806%20C90.8837956,92.5875806%20101.274726,82.1966508%20101.274726,69.3787894%20C101.274726,56.5609279%2090.8837956,46.1699982%2078.0659341,46.1699982%20C65.2480726,46.1699982%2054.8571429,56.5609279%2054.8571429,69.3787894%20C54.8571429,82.1966508%2065.2480726,92.5875806%2078.0659341,92.5875806%20Z%20M23.2087913,139.005163%20C36.0266526,139.005163%2046.4175825,128.614233%2046.4175825,115.796372%20C46.4175825,102.97851%2036.0266526,92.5875806%2023.2087913,92.5875806%20C10.3909298,92.5875806%200,102.97851%200,115.796372%20C0,128.614233%2010.3909298,139.005163%2023.2087913,139.005163%20Z%20M232.791209,139.005163%20C245.60907,139.005163%20256,128.614233%20256,115.796372%20C256,102.97851%20245.60907,92.5875806%20232.791209,92.5875806%20C219.973347,92.5875806%20209.582418,102.97851%20209.582418,115.796372%20C209.582418,128.614233%20219.973347,139.005163%20232.791209,139.005163%20Z'%20fill='%23000000'%3e%3c/path%3e%3cpath%20d='M156.565464,70.3568084%20C155.823426,62.6028163%20155.445577,56.1490255%20149.505494,51.6131676%20C141.982638,45.8687002%20133.461166,49.5960243%20122.964463,45.8072968%20C112.650326,43.3121427%20105,34.1545727%20105,23.2394367%20C105,10.4046502%20115.577888,0%20128.626373,0%20C138.29063,0%20146.599638,5.70747659%20150.259573,13.8825477%20C155.861013,24.5221258%20152.220489,35.3500418%20159.258242,40.8041273%20C167.591489,47.2621895%20178.826167,42.5329154%20191.362109,48.6517412%20C195.390112,50.5026944%20198.799584,53.4384578%20201.202056,57.0769224%20C203.604528,60.7153869%20205,65.0565524%20205,69.7183101%20C205,80.633446%20197.349674,89.7910161%20187.035538,92.2861702%20C176.538834,96.0748977%20168.017363,92.3475736%20160.494506,98.092041%20C152.03503,104.551712%20156.563892,115.358642%20149.669352,126.774447%20C145.756163,134.291567%20137.802119,139.43662%20128.626373,139.43662%20C115.577888,139.43662%20105,129.03197%20105,116.197184%20C105,106.873668%20110.581887,98.832521%20118.637891,95.1306146%20C131.173833,89.0117889%20142.408511,93.7410629%20150.741758,87.2830007%20C155.549106,83.5574243%20156.565464,77.8102648%20156.565464,70.3568084%20Z'%20fill='%23D0021B'%3e%3c/path%3e%3c/g%3e%3c/svg%3e",m=()=>{const o=a.useRef(null);a.useEffect(()=>{document.querySelectorAll("pre code").forEach(r=>{n.highlightBlock(r)})},[]);const t=({code:r})=>e.jsx("pre",{className:"my-4 rounded-lg bg-gray-100 p-4 dark:bg-gray-800",children:e.jsx("code",{ref:o,className:"text-base",children:r})});return e.jsxs("div",{className:"min-h-screen",children:[e.jsxs(s,{children:[e.jsx("title",{children:"React Router 6+ | Help Code It"}),e.jsx("meta",{name:"description",content:"Learn how to use React Router 6+ to manage navigation in your React applications. Understand the basics of routing, setting up routes, and using links with practical examples."}),e.jsx("link",{rel:"canonical",href:"https://www.helpcodeit.com/ReactRouter6"}),e.jsx("meta",{name:"robots",content:"index, follow"}),e.jsx("meta",{name:"keywords",content:"React Router, React Router 6, routing in React, navigation, React tutorial, web development, JavaScript, single-page applications"})]}),e.jsxs("div",{className:"container mx-auto px-4 py-8",children:[e.jsx("h1",{className:"mb-8 text-center text-6xl font-bold text-gray-800 dark:text-gray-100",children:"React Router 6+"}),e.jsxs("div",{className:"grid gap-8 md:grid-cols-3",children:[e.jsx("div",{className:"md:col-span-2",children:e.jsxs("section",{className:"mb-8   p-6  ",children:[e.jsx("h2",{className:"mb-4 text-4xl font-semibold text-gray-800 dark:text-gray-100",children:"Why React Router Exists"}),e.jsx("p",{className:"mb-4 text-2xl text-gray-600 dark:text-gray-300",children:"React is a library for building user interfaces, not a framework. It doesn't come with built-in routing capabilities. React Router fills this gap by providing routing functionality to React applications."}),e.jsx("p",{className:"text-gray-600 text-2xl dark:text-gray-300",children:"In essence, React Router watches the URL and renders the appropriate components based on the current path. It also provides a way to navigate between different URLs within your application."})]})}),e.jsx("div",{className:"md:col-span-1",children:e.jsxs("aside",{className:"rounded-lg bg-gray-50  p-6 shadow-md border border-gray-400 dark:border-gray-300 dark:bg-gray-600",children:[e.jsx("img",{src:i,alt:"React Router Logo",className:" mx-auto mb-4"}),e.jsx("h2",{className:"mb-4 text-4xl font-semibold text-gray-800 dark:text-gray-100 text-center",children:"React Router 6+"}),e.jsx("p",{className:"mb-4 text-lg text-gray-600 dark:text-gray-100  font-bold",children:"React Router 6+ is the latest version of this declarative routing library for React. It allows you to compose your application's navigation rules declaratively."}),e.jsx("div",{className:"grid justify-center",children:e.jsx("a",{href:"https://reactrouter.com/",target:"_blank",rel:"noreferrer",className:" rounded-lg text-lg font-semibold  bg-blue-600 px-4 py-2 text-white transition-colors hover:bg-blue-700",children:"React Router Documentation"})})]})})]}),e.jsx("hr",{className:"my-8 border-t border-gray-300"}),e.jsxs("section",{className:"mb-8 rounded-lg bg-white border border-gray-200 p-6 shadow-md dark:bg-gray-800",children:[e.jsx("h3",{className:"mb-4 text-2xl font-semibold text-gray-800 dark:text-gray-100",children:"Installing React Router"}),e.jsx("p",{className:"mb-2 text-gray-600 dark:text-gray-300",children:"To install React Router, run the following command in your terminal:"}),e.jsx(t,{code:"npm install react-router-dom"})]}),e.jsxs("section",{className:"mb-8 rounded-lg bg-white p-6 shadow-md dark:bg-gray-800 border border-gray-200",children:[e.jsx("h3",{className:"mb-4 text-2xl font-semibold text-gray-800 dark:text-gray-100",children:"Basic Example: index.js/main.js/main.tsx"}),e.jsx("p",{className:"mb-2 text-gray-600 dark:text-gray-300",children:"Here's how to set up BrowserRouter in your index.js/main.js/main.tsx file:"}),e.jsx(t,{code:`
import React from 'react';
import {BrowserRouter} from 'react-router-dom'; // <--- Import BrowserRouter

function index() {
    return (
        <BrowserRouter> {/* <--- Wrap your App component with BrowserRouter */}
        <StrictMode>
            <App />
        </StrictMode>
        </BrowserRouter> {/* <--- Wrap your App component with BrowserRouter */}
    );
}

export default index;
          `})]}),e.jsxs("section",{className:"mb-8 rounded-lg border border-gray-200 bg-white p-6 shadow-md dark:bg-gray-800",children:[e.jsx("h3",{className:"mb-4 text-2xl font-semibold text-gray-800 dark:text-gray-100",children:"Defining Routes"}),e.jsx("p",{className:"mb-2 text-gray-600 dark:text-gray-300",children:"Here's how to define routes in your application in the App.js/App.tsx file:"}),e.jsx(t,{code:`
import React from 'react';
import {Route, Routes} from 'react-router-dom';
import Home from './Home'; // <--- Import your components
import About from './About'; // <--- Import your components
import Contact from './Contact'; // <--- Import your components

function App() {
    return (
        <Routes> {/* <--- Wrap all your Route components with Routes */}
            <Route path="/" element={<Home />} />              {/* <--- Define your routes */}
            <Route path="/about" element={<About />} />        {/* <--- Define your routes */}
            <Route path="/contact" element={<Contact />} />    {/* <--- Define your routes */}
        </Routes> {/* <--- Wrap all your Route components with Routes */}
    );
}

export default App;
          `}),e.jsxs("ul",{className:"mt-4 list-inside list-disc text-gray-600 dark:text-gray-300",children:[e.jsx("li",{children:"The Routes component wraps all Route components."}),e.jsx("li",{children:"Each Route component defines a path and an element to render."}),e.jsx("li",{children:"The element prop takes a JSX element to render when the path matches."})]})]}),e.jsxs("section",{className:"rounded-lg border border-gray-200 bg-white p-6 shadow-md dark:bg-gray-800",children:[e.jsx("h3",{className:"mb-4 text-2xl font-semibold text-gray-800 dark:text-gray-100",children:"Using Links"}),e.jsx("p",{className:"mb-2 text-gray-600 dark:text-gray-300",children:"In React Router, we use the Link component for navigation:"}),e.jsx(t,{code:`
import React from 'react';
import {Link} from 'react-router-dom'; // <--- Import the Link component

function Navbar() {
    return (
        <nav>
            <ul>
                <li>
                    <Link to="/">Home</Link>  {/* <--- Use the Link component */}
                </li>
                <li>
                    <Link to="/about">About</Link> {/* <--- Use the Link component */}
                </li>
                <li>
                    <Link to="/contact">Contact</Link> {/* <--- Use the Link component */}
                </li>
            </ul>
        </nav>
    );
}

export default Navbar;
          `}),e.jsx("p",{className:"mt-4 text-gray-600 dark:text-gray-300",children:"The Link component renders an anchor tag and handles navigation. When a link is clicked, it changes the URL, and BrowserRouter updates the rendered components accordingly."})]})]})]})};export{m as default};
