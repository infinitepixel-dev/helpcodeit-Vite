const e="/assets/michael.UhpzwBOp.jpeg";export{e as m};
