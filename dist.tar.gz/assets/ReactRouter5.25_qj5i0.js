import{j as e,H as a,L as s}from"./index.zTc9QS1j.js";import t from"./CodeBlock.Co3nuMIk.js";import"./ext-beautify.2Job2GVv.js";import"./CopyButton.C7_Pfirw.js";const h=()=>e.jsxs("div",{className:"max-w-4xl p-6 mx-auto",children:[e.jsxs(a,{children:[e.jsx("title",{children:"React Router 5 Guide"}),e.jsx("meta",{name:"description",content:"React Router 5 Guide"}),e.jsx("meta",{name:"keywords",content:"React Router 5, React Router 5 Guide, React Router 5 Tutorial"}),e.jsx("meta",{type:"canonical",src:"https://www.helpcodeit.com/ReactRouter5"})]}),e.jsx("h1",{className:"mb-6 text-3xl font-bold",children:"React Router 5 Guide"}),e.jsx("p",{className:"mb-4",children:"If you are just getting started with React Router, it is highly encouraged that you use React Router 6, as it is the latest version and has many improvements over previous versions. However, if you are working on a project that uses React Router 5, this guide will help you get up to speed with the basics."}),e.jsxs("p",{className:"mb-4",children:["React Router 6 is easier to implement and understand as a whole so if you are trying to decide, head on over to ",e.jsx(s,{to:"/ReactRouter6",className:"font-bold text-blue-500 hover:text-blue-700 hover:underline",children:" React Router 6"})]}),e.jsxs("section",{className:"mb-8",children:[e.jsx("h2",{className:"mb-4 text-2xl font-semibold",children:"1. Installation"}),e.jsx("p",{className:"mb-4",children:"To get started with React Router 5, you first need to install it in your project. You can do this using npm (Node Package Manager) by running the following command in your terminal:"}),e.jsx(t,{code:"npm install react-router-dom@5",language:"sh"}),e.jsx("p",{className:"mt-4",children:"This command installs React Router version 5, which is what we'll be using in this guide."})]}),e.jsxs("section",{className:"mb-8",children:[e.jsx("h2",{className:"mb-4 text-2xl font-semibold",children:"2. Basic Setup"}),e.jsx("p",{className:"mb-4",children:"Here's a basic example of how to set up React Router in your application:"}),e.jsx(t,{code:`
import React from 'react';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';

function App() {
  return (
    <Router>
      <div>
        <nav>
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/about">About</Link></li>
            <li><Link to="/users">Users</Link></li>
          </ul>
        </nav>

        <Switch>
          <Route path="/" exact component={Home} />
          <Route path="/about" component={About} />
          <Route path="/users" component={Users} />
        </Switch>
      </div>
    </Router>
  );
}`,language:"javascript"}),e.jsx("p",{className:"mt-4",children:"Let's break this down:"}),e.jsxs("ul",{className:"mt-2 space-y-2 list-disc list-inside",children:[e.jsx("li",{children:"We import necessary components from 'react-router-dom'."}),e.jsxs("li",{children:["The entire app is wrapped in a ",e.jsx("code",{className:"px-1 text-white bg-gray-600 rounded dark:bg-gray-100 dark:text-black",children:"Router"})," component."]}),e.jsxs("li",{children:["We create a navigation menu using ",e.jsx("code",{className:"px-1 text-white bg-gray-600 rounded dark:bg-gray-100 dark:text-black",children:"Link"})," components."]}),e.jsxs("li",{children:["The ",e.jsx("code",{className:"px-1 text-white bg-gray-600 rounded dark:bg-gray-100 dark:text-black",children:"Switch"})," component ensures only one route is rendered at a time."]}),e.jsxs("li",{children:["Each ",e.jsx("code",{className:"px-1 text-white bg-gray-600 rounded dark:bg-gray-100 dark:text-black",children:"Route"})," defines a path and the component to render for that path."]})]})]}),e.jsxs("section",{className:"mb-8",children:[e.jsx("h2",{className:"mb-4 text-2xl font-semibold",children:"3. Parameterized Routes"}),e.jsx("p",{className:"mb-4",children:"Parameterized routes allow you to create dynamic paths in your application. Here's how you can create and use them:"}),e.jsx(t,{code:`
import React from 'react';
import { useParams } from 'react-router-dom';

function UserProfile() {
  let { id } = useParams();
  return <div>User ID: {id}</div>;
}

// In your route setup:
<Route path="/users/:id" component={UserProfile} />`,language:"javascript"}),e.jsx("p",{className:"mt-4",children:"In this example:"}),e.jsxs("ul",{className:"mt-2 space-y-2 list-disc list-inside",children:[e.jsxs("li",{children:["We define a route with a parameter ",e.jsx("code",{className:"px-1 text-white bg-gray-600 rounded dark:bg-gray-100 dark:text-black",children:":id"}),"."]}),e.jsxs("li",{children:["In the ",e.jsx("code",{className:"px-1 text-white bg-gray-600 rounded dark:bg-gray-100 dark:text-black",children:"UserProfile"})," component, we use the ",e.jsx("code",{className:"px-1 text-white bg-gray-600 rounded dark:bg-gray-100 dark:text-black",children:"useParams"})," hook to access this parameter."]}),e.jsx("li",{children:"This allows us to create dynamic routes like '/users/1', '/users/2', etc."})]})]}),e.jsxs("section",{className:"mb-8",children:[e.jsx("h2",{className:"mb-4 text-2xl font-semibold",children:"4. Programmatic Navigation"}),e.jsx("p",{className:"mb-4",children:"Sometimes you need to navigate to a different route programmatically (e.g., after form submission). Here's how you can do that:"}),e.jsx(t,{code:`
import React from 'react';
import { useHistory } from 'react-router-dom';

function NavigationExample() {
  let history = useHistory();

  function handleClick() {
    history.push('/home');
  }

  return (
    <button onClick={handleClick}>
      Go to Home
    </button>
  );
}`,language:"javascript"}),e.jsx("p",{className:"mt-4",children:"This code demonstrates:"}),e.jsxs("ul",{className:"mt-2 space-y-2 list-disc list-inside",children:[e.jsxs("li",{children:["Using the ",e.jsx("code",{className:"px-1 text-white bg-gray-600 rounded dark:bg-gray-100 dark:text-black",children:"useHistory"})," hook to get access to the history object."]}),e.jsxs("li",{children:["Creating a function that uses ",e.jsx("code",{className:"px-1 text-white bg-gray-600 rounded dark:bg-gray-100 dark:text-black",children:"history.push()"})," to navigate to a new route."]}),e.jsx("li",{children:"Attaching this function to a button's onClick event."})]})]}),e.jsxs("section",{className:"mb-8",children:[e.jsx("h2",{className:"mb-4 text-2xl font-semibold",children:"5. Nested Routes"}),e.jsx("p",{className:"mb-4",children:"React Router 5 allows you to create nested routes, which is useful for creating complex layouts. Here's an example:"}),e.jsx(t,{code:`
import React from 'react';
import { Route, Link, useRouteMatch } from 'react-router-dom';

function Topics() {
  let { path, url } = useRouteMatch();

  return (
    <div>
      <h2>Topics</h2>
      <ul>
        <li>
          <Link to={\`\${url}/rendering\`}>Rendering with React</Link>
        </li>
        <li>
          <Link to={\`\${url}/components\`}>Components</Link>
        </li>
      </ul>

      <Route exact path={path}>
        <h3>Please select a topic.</h3>
      </Route>
      <Route path={\`\${path}/:topicId\`}>
        <Topic />
      </Route>
    </div>
  );
}

function Topic() {
  let { topicId } = useParams();
  return <h3>Requested topic ID: {topicId}</h3>;
}`,language:"javascript"}),e.jsx("p",{className:"mt-4",children:"This example shows:"}),e.jsxs("ul",{className:"mt-2 space-y-2 list-disc list-inside",children:[e.jsxs("li",{children:["Using ",e.jsx("code",{className:"px-1 text-white bg-gray-600 rounded dark:bg-gray-100 dark:text-black",children:"useRouteMatch"})," to get the current ",e.jsx("code",{className:"px-1 text-white bg-gray-600 rounded dark:bg-gray-100 dark:text-black",children:"path"})," and ",e.jsx("code",{className:"px-1 text-white bg-gray-600 rounded dark:bg-gray-100 dark:text-black",children:"url"}),"."]}),e.jsxs("li",{children:["Creating nested ",e.jsx("code",{className:"px-1 text-white bg-gray-600 rounded dark:bg-gray-100 dark:text-black",children:"Link"})," components that append to the current URL."]}),e.jsxs("li",{children:["Defining nested ",e.jsx("code",{className:"px-1 text-white bg-gray-600 rounded dark:bg-gray-100 dark:text-black",children:"Route"})," components."]}),e.jsxs("li",{children:["Using a parameterized route for topics (",e.jsx("code",{className:"px-1 text-white bg-gray-600 rounded dark:bg-gray-100 dark:text-black",children:":topicId"}),")."]})]})]}),e.jsx("p",{className:"mt-8 text-gray-600",children:"This guide covers the basics of React Router 5. As you become more comfortable with these concepts, you can explore more advanced features in the official React Router documentation."})]});export{h as default};
