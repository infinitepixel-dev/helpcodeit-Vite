const s="/assets/visual-studio-code.zVAWFD4C.svg";export{s as v};
