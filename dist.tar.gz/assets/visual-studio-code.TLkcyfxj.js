const s="/assets/visual-studio-code.BC_h-9TH.svg";export{s as v};
