const s="/assets/React.BwygIBQc.svg";export{s as r};
