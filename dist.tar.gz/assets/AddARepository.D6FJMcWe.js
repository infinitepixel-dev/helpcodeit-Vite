import{j as e}from"./index.D2dmul_t.js";import i from"./CodeBlock.DcpLYaKa.js";import"./ext-beautify.moJIAcHp.js";import"./CopyButton.wsQw8STc.js";const c=()=>e.jsxs("div",{className:"container grid justify-center",children:[e.jsxs("h1",{className:"my-8 text-5xl font-bold",children:["How to Create a ",e.jsx("br",{})," GitHub Repository ",e.jsx("br",{}),"and Add Files"]}),e.jsxs("ol",{className:"list-inside",children:[e.jsxs("li",{className:"mb-4",children:[e.jsx("h2",{className:"text-xl font-semibold",children:"Create a New Repository on GitHub"}),e.jsxs("p",{className:"ml-4",children:['1. Log in to GitHub and click the "+" icon at the top-right corner, then select "New repository".',e.jsx("br",{}),"2. Enter a repository name (e.g., ",e.jsx("span",{className:"font-mono italic",children:"my-new-repo"}),").",e.jsx("br",{}),"3. Optionally add a description.",e.jsx("br",{}),"4. Choose the repository visibility: Public or Private.",e.jsx("br",{}),"5. ",e.jsx("strong",{children:"DO NOT"})," initialize the repository with a README, .gitignore, or license.",e.jsx("br",{}),'6. Click the "Create repository" button.']})]}),e.jsxs("li",{className:"mb-4",children:[e.jsx("h2",{className:"text-xl font-semibold",children:"Set Up Local Repository"}),e.jsxs("p",{className:"ml-4",children:["1. Open your terminal or command prompt.",e.jsx("br",{}),"2. Navigate to the correct directory where you want to initialize your Git repository.",e.jsx("br",{}),e.jsx("strong",{children:"Warning:"})," Make sure you are in the right folder before proceeding."]})]}),e.jsxs("li",{className:"mb-4",children:[e.jsx("h2",{className:"text-xl font-semibold",children:"Initialize Local Repository"}),e.jsx("p",{className:"ml-4",children:"Run the following command to initialize a new Git repository in your current directory:"}),e.jsx(i,{code:"git init",language:"bash"})]}),e.jsxs("li",{className:"mb-4",children:[e.jsx("h2",{className:"text-xl font-semibold",children:"Add Remote Repository"}),e.jsx("p",{className:"ml-4",children:"Copy the repository URL from GitHub and run the following command:"}),e.jsx(i,{code:"git remote add origin https://github.com/your-username/my-new-repo.git",language:"sh"})]}),e.jsxs("li",{className:"mb-4",children:[e.jsx("h2",{className:"text-xl font-semibold",children:"Create and Push Initial Commit"}),e.jsx("p",{className:"ml-4",children:"Create a README file or another initial file, add it to the staging area, commit it, and push to GitHub:"}),e.jsx(i,{code:`echo "# My New Repo" > README.md
git add README.md
git commit -m "Initial commit"
git push -u origin master`,language:"bash"})]}),e.jsxs("li",{className:"mb-4",children:[e.jsx("h2",{className:"text-xl font-semibold",children:"Add Additional Files"}),e.jsx("p",{className:"ml-4",children:"Add the remaining files, commit, and push the changes:"}),e.jsx(i,{code:`git add .
git commit -m "Add all project files"
git push`,language:"bash"})]})]}),e.jsx("h2",{className:"mt-6 text-xl font-semibold",children:"Summary of Commands"}),e.jsx("p",{className:"mb-4",children:"These are the command listed in the box with the copy button just under the box containing the address of the repository. Feel free to copy the ones on the GitHub page and paste them in your terminal."}),e.jsx(i,{code:`
  # Navigate to your project directory
  cd path/to/your/project

  # Initialize Git repository
  git init

  # Add remote repository
  git remote add origin https://github.com/your-username/my-new-repo.git

  # Create initial file and add to staging
  echo "# My New Repo" > README.md
  git add README.md

  # Commit the changes
  git commit -m "Initial commit"

  # Push to GitHub
  git push -u origin master

  # Add remaining files
  git add .
  git commit -m "Add all project files"
  git push
  `,language:"bash"}),e.jsx("h2",{className:"mt-6 text-xl font-semibold",children:"Warnings and Tips"}),e.jsxs("ul",{className:"mb-5 ml-4 list-disc list-inside",children:[e.jsxs("li",{children:["Ensure you are in the correct directory before running ",e.jsx("span",{className:"italic",children:"git init"}),"."]}),e.jsx("li",{children:"Do not change any settings during repository creation other than naming the repository."}),e.jsx("li",{children:"Use meaningful commit messages to keep track of changes."}),e.jsxs("li",{children:["Check the status of your repository with ",e.jsx("span",{className:"italic",children:"git status"})," to see which files are staged for commit."]})]}),e.jsxs("div",{className:"grid grid-cols-2 my-10",children:[e.jsxs("div",{className:"grid justify-center col-span-2 lg:col-span-1 min-w-fit",children:[e.jsx("h2",{className:"mt-6 text-xl font-semibold text-center",children:"Terminal Video Tutorial"}),e.jsx("iframe",{width:"560",height:"315",src:"https://www.youtube.com/embed/sIUTpwiRXfs?si=QrheJgtJerUkgWsW",title:"YouTube video player",frameborder:"0",allow:"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",referrerpolicy:"strict-origin-when-cross-origin",allowfullscreen:!0})]}),e.jsxs("div",{className:"grid justify-center col-span-2 lg:col-span-1 min-w-fit",children:[e.jsx("h2",{className:"mt-6 text-xl font-semibold text-center",children:"VS Code Source Control Video Tutorial"}),e.jsx("iframe",{width:"560",height:"315",src:"https://www.youtube.com/embed/5Cvq9zM5qVE?si=dAqPFfhcK-s1uHM2",title:"YouTube video player",frameborder:"0",allow:"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",referrerpolicy:"strict-origin-when-cross-origin",allowfullscreen:!0})]})]})]});export{c as default};
