import{j as e}from"./index.BFC7j04M.js";import t from"./CodeBlock.8PTxbhPh.js";import"./ext-beautify.qBD3D6Fq.js";import"./CopyButton.D5fQR8rW.js";function s(){return e.jsxs("div",{className:"container px-4 py-8 mx-auto",children:[e.jsx("h1",{className:"mb-6 text-5xl font-bold text-center roboto-font text-balance",children:"Tanstack Query vs useEffect for API Data Fetching"}),e.jsxs("section",{className:"mb-8",children:[e.jsx("h2",{className:"mb-4 text-2xl font-semibold",children:"Why Tanstack Query?"}),e.jsx("p",{className:"mb-4",children:"Tanstack Query (formerly React Query) offers several advantages over using useEffect for API data fetching:"}),e.jsxs("ul",{className:"mb-4 list-disc list-inside",children:[e.jsx("li",{children:"Automatic caching and refetching"}),e.jsx("li",{children:"Built-in loading and error states"}),e.jsx("li",{children:"Easier pagination and infinite scrolling"}),e.jsx("li",{children:"Optimistic updates"}),e.jsx("li",{children:"Automatic background refetching"})]})]}),e.jsxs("section",{className:"mb-8",children:[e.jsx("h2",{className:"mb-4 text-2xl font-semibold",children:"useEffect Approach"}),e.jsx("p",{className:"mb-4",children:"This example demonstrates how to fetch data using the useEffect hook. It shows the basic structure of managing loading states, error handling, and data storage using React's built-in hooks:"}),e.jsx(t,{code:`
import React, { useState, useEffect } from 'react';

function UserData() {
  const [userData, setUserData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/users/1')
      .then(response => response.json())
      .then(data => {
        setUserData(data);
        setIsLoading(false);
      })
      .catch(error => {
        setError(error);
        setIsLoading(false);
      });
  }, []);

  if (isLoading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div>
      <h2>{userData.name}</h2>
      <p>{userData.email}</p>
    </div>
  );
}`,language:"javascript"})]}),e.jsxs("section",{className:"mb-8",children:[e.jsx("h2",{className:"mb-4 text-2xl font-semibold",children:"Tanstack Query Approach"}),e.jsx("p",{className:"mb-4",children:"First, you need to install Tanstack Query. You can do this by running the following command in your project directory:"}),e.jsx(t,{code:"npm install @tanstack/react-query",language:"bash"}),e.jsx("p",{className:"my-4",children:"Here's how you can achieve the same result using Tanstack Query. Notice how it simplifies state management and provides a more declarative approach to data fetching:"}),e.jsx(t,{code:`
import React from 'react';
import { useQuery } from '@tanstack/react-query';

const fetchUserData = async () => {
  const response = await fetch('https://jsonplaceholder.typicode.com/users/1');
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
};

function UserData() {
  const { data, isLoading, error } = useQuery(['userData'], fetchUserData);

  if (isLoading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div>
      <h2>{data.name}</h2>
      <p>{data.email}</p>
    </div>
  );
}`,language:"javascript"})]}),e.jsxs("section",{className:"mb-8",children:[e.jsx("h2",{className:"mb-4 text-2xl font-semibold",children:"Custom Hook Approach (Without Tanstack Query)"}),e.jsx("p",{className:"mb-4",children:"If you prefer not to use Tanstack Query, you can create a custom hook to achieve similar functionality. This example shows how to encapsulate the data fetching logic in a reusable hook:"}),e.jsx(t,{code:`
import { useState, useEffect } from 'react';

function useFetch(url) {
  const [data, setData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let isMounted = true;
    const fetchData = async () => {
      try {
        const response = await fetch(url);
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const result = await response.json();
        if (isMounted) {
          setData(result);
          setIsLoading(false);
        }
      } catch (error) {
        if (isMounted) {
          setError(error);
          setIsLoading(false);
        }
      }
    };

    fetchData();

    return () => {
      isMounted = false;
    };
  }, [url]);

  return { data, isLoading, error };
}

function UserData() {
  const { data, isLoading, error } = useFetch('https://jsonplaceholder.typicode.com/users/1');

  if (isLoading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div>
      <h2>{data.name}</h2>
      <p>{data.email}</p>
    </div>
  );
}`,language:"javascript"})]}),e.jsxs("section",{className:"mb-8",children:[e.jsx("h2",{className:"mb-4 text-2xl font-semibold",children:"Comparison"}),e.jsx("p",{className:"mb-4",children:"Let's compare these three approaches to help beginners understand their merits and intended purposes:"}),e.jsx("h3",{className:"mb-2 text-xl font-semibold",children:"1. useEffect Approach"}),e.jsxs("p",{className:"mb-4",children:[e.jsx("strong",{children:"Merits:"}),e.jsxs("ul",{className:"mb-2 ml-4 list-disc list-inside",children:[e.jsx("li",{children:"Simple and straightforward for beginners"}),e.jsx("li",{children:"Uses built-in React hooks, no additional libraries needed"}),e.jsx("li",{children:"Good for learning how React works with side effects"})]}),e.jsx("strong",{children:"Intended purpose:"})," Best for simple, one-off data fetching in small applications or when learning React basics."]}),e.jsx("h3",{className:"mb-2 text-xl font-semibold",children:"2. Tanstack Query Approach"}),e.jsxs("p",{className:"mb-4",children:[e.jsx("strong",{children:"Merits:"}),e.jsxs("ul",{className:"mb-2 ml-4 list-disc list-inside",children:[e.jsx("li",{children:"Automatic caching and background refetching"}),e.jsx("li",{children:"Built-in loading and error states"}),e.jsx("li",{children:"Optimized for performance in larger applications"}),e.jsx("li",{children:"Reduces boilerplate code"})]}),e.jsx("strong",{children:"Intended purpose:"})," Ideal for medium to large applications with complex data fetching needs, or when you need advanced features like caching and synchronization out of the box."]}),e.jsx("h3",{className:"mb-2 text-xl font-semibold",children:"3. Custom Hook Approach"}),e.jsxs("p",{className:"mb-4",children:[e.jsx("strong",{children:"Merits:"}),e.jsxs("ul",{className:"mb-2 ml-4 list-disc list-inside",children:[e.jsx("li",{children:"Reusable across components"}),e.jsx("li",{children:"More control over implementation than Tanstack Query"}),e.jsx("li",{children:"Can be tailored to specific project needs"}),e.jsx("li",{children:"No additional library dependencies"})]}),e.jsx("strong",{children:"Intended purpose:"})," Great for small to medium-sized applications where you want more reusability than the useEffect approach, but don't need the full feature set of Tanstack Query."]}),e.jsx("p",{className:"mt-4",children:"For beginners, starting with the useEffect approach is a good way to understand how data fetching works in React. As you build more complex applications, you might find the custom hook approach helpful for organizing your code better. When you're working on larger projects or need advanced features, Tanstack Query can significantly simplify your data management."})]})]})}s.meta={title:"Tanstack Query vs useEffect | Help Code It",description:"Learn why Tanstack Query is better than useEffect for API data fetching in React applications.","og:title":"Tanstack Query vs useEffect for React Data Fetching","og:description":"Discover the advantages of using Tanstack Query over useEffect for API data fetching in React apps.","og:image":"https://www.helpcodeit.com/images/tanstack-query.png","og:url":"https://www.helpcodeit.com/TanstackQuery","twitter:title":"Tanstack Query vs useEffect for React Data Fetching","twitter:description":"Learn why Tanstack Query is superior to useEffect for API data fetching in React applications.","twitter:image":"https://www.helpcodeit.com/images/tanstack-query.png",path:"/TanstackQuery",layout:"default",requiresAuth:!1,roles:[],breadcrumbs:[{name:"Home",path:"/"},{name:"React",path:"/ReactMain"},{name:"Tanstack Query",path:"/TanstackQuery"}]};export{s as default};
