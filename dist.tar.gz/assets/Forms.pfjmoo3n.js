import{j as e}from"./index.D2dmul_t.js";import a from"./CodeBlock.DcpLYaKa.js";import"./mode-html.jZYdjdYr.js";import"./mode-css.Bol8x519.js";import{T as t}from"./text-cursor-input.D5kBayph.js";import{c as s}from"./createLucideIcon.DFMxCUwd.js";import{L as n}from"./layers.DcvSsAwI.js";import{I as l}from"./info.DUtQ9tug.js";import"./ext-beautify.moJIAcHp.js";import"./CopyButton.wsQw8STc.js";/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i=s("AlignCenter",[["path",{d:"M17 12H7",key:"16if0g"}],["path",{d:"M19 18H5",key:"18s9l3"}],["path",{d:"M21 6H3",key:"1jwq7v"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=s("SquareCheckBig",[["path",{d:"M21 10.5V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h12.5",key:"1uzm8b"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]]),g=()=>e.jsxs("div",{className:"container p-8 mb-24",children:[e.jsx("h1",{className:"mb-4 text-5xl font-bold text-balance",children:"Understanding Forms in HTML"}),e.jsx("p",{className:"mb-6",children:"Forms are a crucial part of web development, allowing users to input and submit data. HTML provides various elements to create forms for different purposes."}),e.jsxs("section",{className:"mb-8",children:[e.jsxs("h2",{className:"flex items-center mb-2 text-2xl font-semibold",children:[e.jsx(t,{className:"mr-2"})," Basic Form Structure"]}),e.jsxs("p",{className:"mb-4",children:["A form in HTML is created using the ",e.jsx("code",{className:"border-none shadow-none",children:"<form>"})," element. Inside it, you define different input elements such as text fields, checkboxes, radio buttons, etc. Here’s an example of a simple form:"]}),e.jsx(a,{code:`<form action="/submit" method="POST">
  <label for="name">Name:</label>
  <input type="text" id="name" name="name">

  <label for="email">Email:</label>
  <input type="email" id="email" name="email">

  <input type="submit" value="Submit">
</form>`,language:"html"})]}),e.jsxs("section",{className:"mb-8",children:[e.jsxs("h2",{className:"flex items-center mb-2 text-2xl font-semibold",children:[e.jsx(r,{className:"mr-2"})," Input Types"]}),e.jsx("p",{className:"mb-4",children:"HTML provides a variety of input types to cater to different data inputs. Here are some commonly used input types:"}),e.jsx(a,{code:`<form>
  <label for="text">Text:</label>
  <input type="text" id="text" name="text">

  <label for="password">Password:</label>
  <input type="password" id="password" name="password">

  <label for="number">Number:</label>
  <input type="number" id="number" name="number">

  <label for="email">Email:</label>
  <input type="email" id="email" name="email">

  <label for="date">Date:</label>
  <input type="date" id="date" name="date">

  <label for="checkbox">Checkbox:</label>
  <input type="checkbox" id="checkbox" name="checkbox">

  <label for="radio">Radio:</label>
  <input type="radio" id="radio" name="radio">

  <input type="submit" value="Submit">
</form>`,language:"html"})]}),e.jsxs("section",{className:"mb-8",children:[e.jsxs("h2",{className:"flex items-center mb-2 text-2xl font-semibold",children:[e.jsx(i,{className:"mr-2"})," Grouping Form Elements"]}),e.jsxs("p",{className:"mb-4",children:["You can group related form elements using the ",e.jsx("code",{className:"border-none shadow-none",children:"<fieldset>"})," element, and provide a caption using the ",e.jsx("code",{className:"border-none shadow-none",children:"<legend>"})," element. This helps in better organization and readability:"]}),e.jsx(a,{code:`<form>
  <fieldset>
    <legend>Personal Information</legend>

    <label for="name">Name:</label>
    <input type="text" id="name" name="name">

    <label for="email">Email:</label>
    <input type="email" id="email" name="email">
  </fieldset>

  <input type="submit" value="Submit">
</form>`,language:"html"})]}),e.jsxs("section",{className:"mb-8",children:[e.jsxs("h2",{className:"flex items-center mb-2 text-2xl font-semibold",children:[e.jsx(n,{className:"mr-2"})," Form Validation"]}),e.jsxs("p",{className:"mb-4",children:["Form validation ensures that the user inputs data correctly before submitting the form. HTML5 provides built-in validation attributes like ",e.jsx("code",{className:"border-none shadow-none",children:"required"}),", ",e.jsx("code",{className:"border-none shadow-none",children:"minlength"}),",",e.jsx("code",{className:"border-none shadow-none",children:"maxlength"}),", and more:"]}),e.jsx(a,{code:`<form>
  <label for="username">Username:</label>
  <input type="text" id="username" name="username" required minlength="4" maxlength="8">

  <label for="email">Email:</label>
  <input type="email" id="email" name="email" required>

  <label for="age">Age:</label>
  <input type="number" id="age" name="age" min="18" max="100">

  <input type="submit" value="Submit">
</form>`,language:"html"})]}),e.jsxs("section",{children:[e.jsxs("h2",{className:"flex items-center mb-2 text-2xl font-semibold",children:[e.jsx(l,{className:"mr-2"})," Best Practices for Using Forms"]}),e.jsxs("ul",{className:"ml-6 list-disc",children:[e.jsxs("li",{className:"mb-2",children:[e.jsx("strong",{children:"Use Proper Input Types"}),": Choose the correct input type for the data you’re collecting to enhance user experience and data accuracy."]}),e.jsxs("li",{className:"mb-2",children:[e.jsx("strong",{children:"Validate User Input"}),": Ensure data integrity by validating user input both on the client side and server side."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Group Related Inputs"}),": Use ",e.jsx("code",{className:"border-none shadow-none",children:"<fieldset>"})," and ",e.jsx("code",{className:"border-none shadow-none",children:"<legend>"})," to group related form elements, making the form more accessible and easier to navigate."]})]})]})]});export{g as default};
