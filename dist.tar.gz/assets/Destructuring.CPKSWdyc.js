import{r,j as e,H as t}from"./index.D-o3K8gs.js";import s from"./CodeBlock.9M43XyIu.js";import"./ext-beautify.DLsk9G3U.js";import"./CopyButton.q9lS4ju6.js";function o(){return r.useRef(null),e.jsxs("div",{className:"pb-14",children:[e.jsxs(t,{children:[e.jsx("title",{children:"Destructuring Props in React"}),e.jsx("meta",{name:"description",content:"Learn how to destructure props in React to make your code cleaner and more readable. Includes examples for function components and class components."}),e.jsx("meta",{name:"keywords",content:"React, destructuring props, JavaScript, function components, class components"})]}),e.jsxs("div",{className:"container px-4 mx-auto",children:[e.jsx("h1",{className:"my-5 text-6xl text-center",children:"Destructuring Props in React"}),e.jsx("hr",{className:"my-4"}),e.jsxs("section",{children:[e.jsx("h2",{className:"my-4 text-4xl",children:"What is Destructuring?"}),e.jsx("p",{children:"Destructuring is a JavaScript feature that allows you to unpack values from arrays or properties from objects into distinct variables. In React, destructuring props helps you extract specific properties from the props object, making your code simpler and easier to understand."})]}),e.jsxs("section",{children:[e.jsx("h2",{className:"my-4 text-4xl",children:"Benefits of Destructuring Props"}),e.jsxs("ul",{className:"list-disc list-inside",children:[e.jsxs("li",{children:[e.jsx("strong",{children:"Clarity:"})," Destructuring makes it clear which props a component is using."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Conciseness:"})," It reduces the amount of code you need to write, avoiding repetitive ",e.jsx("i",{children:"props."})," references."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Readability:"})," Your code becomes more readable and easier to maintain."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Avoiding Typos:"})," Destructuring can help prevent typos by reducing the number of times you need to type ",e.jsx("i",{children:"props."})]})]})]}),e.jsxs("section",{children:[e.jsx("h2",{className:"my-4 text-4xl",children:"Basic Destructuring in Function Components"}),e.jsx(s,{language:"javascript",code:`import React from 'react';

function Greeting(props) {
  const { name } = props;
  return <h1>Hello, {name}!</h1>;
}

export default Greeting;`}),e.jsxs("p",{children:["To destructure the ",e.jsx("i",{children:"name"})," prop, you can modify the function parameter:"]}),e.jsx(s,{language:"javascript",code:`import React from 'react';

function Greeting({ name }) {
  return <h1>Hello, {name}!</h1>;
}

export default Greeting;`})]}),e.jsxs("section",{children:[e.jsx("h2",{className:"my-4 text-4xl",children:"Destructuring Multiple Props"}),e.jsx("p",{children:"You can destructure multiple props in a single line:"}),e.jsx(s,{language:"javascript",code:`import React from 'react';

function UserCard(props) {
  const { name, email } = props;
  return (
    <div>
      <h2>{name}</h2>
      <p>{email}</p>
    </div>
  );
}

export default UserCard;`}),e.jsxs("p",{children:["Destructure the ",e.jsx("i",{children:"name"})," and ",e.jsx("i",{children:"email"})," props:"]}),e.jsx(s,{language:"javascript",code:`import React from 'react';

function UserCard({ name, email }) {
  return (
    <div>
      <h2>{name}</h2>
      <p>{email}</p>
    </div>
  );
}

export default UserCard;`})]}),e.jsxs("section",{children:[e.jsx("h2",{className:"my-4 text-4xl",children:"Destructuring in Class Components"}),e.jsx(s,{language:"javascript",code:`import React, { Component } from 'react';

class UserProfile
  extends Component {
  render() {
    const { name, email } = this.props;
    return (
      <div>
        <h2>{name}</h2>
        <p>{email}</p>
      </div>
    );
  }
}

export default UserProfile;`})]}),e.jsxs("section",{children:[e.jsx("h2",{className:"my-4 text-4xl",children:"Destructuring with Default Values"}),e.jsx("p",{children:"You can also provide default values when destructuring props. This is useful when a prop might not be passed:"}),e.jsx(s,{language:"javascript",code:`import React from 'react';

function WelcomeMessage(props) {
  const { username = 'Guest' } = props;
  return <h1>Welcome, {username}!</h1>;
}

export default WelcomeMessage;`})]}),e.jsxs("section",{children:[e.jsx("h2",{className:"my-4 text-4xl",children:"Destructuring Nested Props"}),e.jsx("p",{children:"If your props contain nested objects, you can destructure them as well:"}),e.jsx(s,{language:"javascript",code:`import React from 'react';

function Address(props) {
  const { user } = props;
  const { name, address } = user;
  const { city } = address;
  return (
    <div>
      <h3>{name}</h3>
      <p>{city}</p>
    </div>
  );
}

export default Address;`}),e.jsxs("p",{children:["Destructure the nested ",e.jsx("i",{children:"user"})," prop:"]}),e.jsx(s,{language:"javascript",code:`import React from 'react';

function Address({ user: { name, address: { city } } }) {
  return (
    <div>
      <h3>{name}</h3>
      <p>{city}</p>
    </div>
  );
}

export default Address;`})]}),e.jsxs("section",{children:[e.jsx("h2",{className:"my-4 text-4xl",children:"Practical Examples"}),e.jsx("h3",{className:"my-3 text-3xl",children:"Example 1: Destructuring Props in a Functional Component"}),e.jsx(s,{language:"javascript",code:`import React from 'react';

function Greeting({ name }) {
  return <h1>Hello, {name}!</h1>;
}

export default Greeting;`}),e.jsx("h3",{className:"my-3 text-3xl",children:"Example 2: Destructuring Props with Default Values"}),e.jsx(s,{language:"javascript",code:`import React from 'react';

function WelcomeMessage({ username = 'Guest' }) {
  return <h1>Welcome, {username}!</h1>;
}

export default WelcomeMessage;`}),e.jsx("h3",{className:"my-3 text-3xl",children:"Example 3: Destructuring Nested Props"}),e.jsx(s,{language:"javascript",code:`import React from 'react';

function Address({ user: { name, address: { city } } }) {
  return (
    <div>
      <h3>{name}</h3>
      <p>{city}</p>
    </div>
  );
}

export default Address;`})]})]})]})}export{o as default};
