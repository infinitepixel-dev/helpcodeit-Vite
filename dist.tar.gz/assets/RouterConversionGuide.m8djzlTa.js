import{j as e}from"./index.D-o3K8gs.js";import t from"./CodeBlock.9M43XyIu.js";import"./ext-beautify.DLsk9G3U.js";import"./CopyButton.q9lS4ju6.js";const m=()=>e.jsxs("div",{className:"container p-8 mx-auto",children:[e.jsx("h1",{className:"mb-6 text-4xl font-bold text-center",children:"Convert React Router 5 to React Router 6"}),e.jsxs("section",{className:"mb-8",children:[e.jsx("h2",{className:"mb-4 text-2xl font-semibold",children:"1. Installation"}),e.jsx("p",{className:"mb-2",children:"The first step is to install React Router 6. If you already have React Router 5 installed, you'll need to update it:"}),e.jsx(t,{code:"npm install react-router-dom@latest",language:"sh"}),e.jsx("p",{className:"mt-2",children:"This will install the latest version of React Router, which includes all the features of React Router 6."})]}),e.jsxs("section",{className:"mb-8",children:[e.jsx("h2",{className:"mb-4 text-2xl font-semibold",children:"2. Switch to `BrowserRouter`"}),e.jsx("p",{className:"mb-2",children:"In React Router 6, `BrowserRouter` is still used as the top-level component to enable routing. No change is needed if you already use it."}),e.jsx("p",{className:"mb-2",children:"This part remains the same in React Router 6 but we do recommend pushing it to the main.jsx or index.jsx file."}),e.jsx("p",{className:"mb-2",children:"Example:"}),e.jsx(t,{code:`import { BrowserRouter } from 'react-router-dom';

function App() {
  return (
    <BrowserRouter>
      <YourRoutes />
    </BrowserRouter>
  );
}`,language:"javascript"})]}),e.jsxs("section",{className:"mb-8",children:[e.jsx("h2",{className:"mb-4 text-2xl font-semibold",children:"3. Changes to `Switch`"}),e.jsx("p",{className:"mb-2",children:"The `Switch` component has been replaced by `Routes` in React Router 6. This change is necessary because `Routes` adds additional functionality, like route ranking."}),e.jsx("p",{className:"mb-2",children:"Example:"}),e.jsx(t,{code:`// React Router 5
import { Switch, Route } from 'react-router-dom';

function YourRoutes() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/about" component={About} />
    </Switch>
  );
}
// Reaact Router 6
import { Routes, Route } from 'react-router-dom';

function YourRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/about" element={<About />} />
    </Routes>
  );
}`,language:"javascript"})]}),e.jsxs("section",{className:"mb-8",children:[e.jsx("h2",{className:"mb-4 text-2xl font-semibold",children:"4. Route Changes"}),e.jsx("p",{className:"mb-2",children:"In React Router 6, the `component` prop is replaced with the `element` prop, and you need to pass JSX directly to it. This is one of the more common changes you'll need to make when converting from React Router 5 to React."}),e.jsx("p",{className:"mb-2",children:"Example:"}),e.jsx(t,{code:`// React Router 5
<Route path="/about" component={About} />

// React Router 6
<Route path="/about" element={<About />} />`,language:"javascript"})]}),e.jsxs("section",{className:"mb-8",children:[e.jsx("h2",{className:"mb-4 text-2xl font-semibold",children:"5. `useHistory` to `useNavigate`"}),e.jsx("p",{className:"mb-2",children:"In React Router 6, `useHistory` has been replaced with `useNavigate`. This new hook provides a simpler and more intuitive way to navigate programmatically. You can use it in the same way as `useHistory`, but with a more descriptive name."}),e.jsx("p",{className:"mb-2",children:"Example:"}),e.jsx(t,{code:`// React Router 5
import { useHistory } from 'react-router-dom';

function MyComponent() {
  let history = useHistory();
  const navigateHome = () => {
    history.push('/');
  };
}

// React Router 6
import { useNavigate } from 'react-router-dom';

function MyComponent() {
  let navigate = useNavigate();
  const navigateHome = () => {
    navigate('/');
  };
}`,language:"javascript"})]}),e.jsxs("section",{children:[e.jsx("h2",{className:"mb-4 text-2xl font-semibold",children:"That's It!"}),e.jsx("p",{children:"These are the key changes you need to be aware of when migrating from React Router 5 to React Router 6. By following these steps, you can take advantage of the new features and improvements in React Router 6 as well as keep your codebase up to date. React Router 6 is far easier to use and more intuitive than its predecessor, so the effort to migrate is well worth it."})]})]});export{m as default};
