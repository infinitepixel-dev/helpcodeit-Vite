import{j as e,H as l}from"./index.DVhBk_qR.js";import t from"./CodeBlock.CoARszfP.js";import"./mode-html.jZYdjdYr.js";import"./mode-css.Bol8x519.js";import{L as i}from"./list.DbecBTcB.js";import{c as a}from"./createLucideIcon.C-xcwTHi.js";import{I as r}from"./info.CrgX1FaB.js";import{C as n}from"./chevrons-right.BhJ3cFXf.js";import{C as o}from"./code.CpOgDtUH.js";import{C as d}from"./chevron-right.BxIGYM2x.js";import"./ext-beautify.CXC0wS6f.js";import"./CopyButton.8kEOxNCf.js";/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=a("ListOrdered",[["path",{d:"M10 12h11",key:"6m4ad9"}],["path",{d:"M10 18h11",key:"11hvi2"}],["path",{d:"M10 6h11",key:"c7qv1k"}],["path",{d:"M4 10h2",key:"16xx2s"}],["path",{d:"M4 6h1v4",key:"cnovpq"}],["path",{d:"M6 18H4c0-1 2-2 2-3s-1-1.5-2-1",key:"m9a95d"}]]),m="/assets/listSloth.D7jZvjb3.webp",M=()=>{let s=[{code:`<ol>
    <li>Preheat the oven to 350°F (175°C).</li>
    <li>Mix the flour, sugar, and eggs in a bowl.</li>
    <li>Bake for 30 minutes.</li>
</ol>`,language:"html"},{code:`<ul>
    <li>Milk</li>
    <li>Bread</li>
    <li>Eggs</li>
</ul>`,language:"html"},{code:`<dl>
    <dt>HTML</dt>
    <dd>A standard markup language for creating web pages.</dd>
    <dt>CSS</dt>
    <dd>A stylesheet language used to describe the presentation of a document written in HTML.</dd>
</dl>`,language:"html"},{code:`<ul>
    <li>Fruits
        <ul>
            <li>Apples</li>
            <li>Oranges</li>
        </ul>
    </li>
    <li>Vegetables
        <ul>
            <li>Carrots</li>
            <li>Broccoli</li>
        </ul>
    </li>
</ul>`,language:"html"},{code:`<ol start="5">
    <li>Item 1</li>
    <li>Item 2</li>
</ol>`,language:"html"},{code:`<ul>
    <li>Custom bullet 1</li>
    <li>Custom bullet 2</li>
</ul>`,language:"html"},{code:`ul.custom-bullets {
            list-style-type: square;
            `,language:"css"}];return e.jsxs("div",{className:"container p-8",children:[e.jsxs(l,{children:[e.jsx("title",{children:"Understanding Lists in HTML | Help Code It"}),e.jsx("meta",{name:"description",content:"Learn how to create ordered, unordered, and description lists in HTML. Lists are a fundamental part of HTML, allowing you to organize content in a structured, easy-to-read format."}),e.jsx("meta",{property:"og:title",content:"Understanding Lists in HTML | Help Code It"}),e.jsx("meta",{name:"keywords",content:"HTML Lists, HTML Ordered Lists, HTML Unordered Lists, HTML Description Lists"}),e.jsx("meta",{canonical:"https://www.helpcodeit.com/htmlPages/HTMLLists"})]}),e.jsxs("div",{className:"flex items-center justify-center mb-8",children:[e.jsx(i,{className:"my-auto mb-3 h-14 w-14 me-4"}),e.jsx("h1",{className:"my-auto mb-4 text-5xl font-bold",children:"Understanding Lists in HTML "})]}),e.jsxs("p",{className:"mb-6",children:["Lists are a fundamental part of HTML, allowing you to organize content in a structured, easy-to-read format. Whether you want to display a series of items, steps in a process, or a collection of related content, HTML provides a simple way to create lists.",e.jsx("img",{src:m,alt:"List Sloth",className:"hidden float-right w-2/5 m-3 rounded-lg md:block"})]}),e.jsxs("section",{className:"mb-8",children:[e.jsxs("h2",{className:"flex items-center mb-2 text-2xl font-semibold",children:[e.jsx(i,{className:"mr-2"})," Types of Lists in HTML"]}),e.jsx("p",{className:"mb-4",children:"HTML supports three primary types of lists:"}),e.jsxs("ul",{className:"ml-6 list-disc",children:[e.jsxs("li",{className:"mb-2",children:[e.jsx("strong",{children:"Ordered Lists (`<ol>`)"}),": An ordered list is used when the order of items is important, such as a sequence of steps in a procedure. Items in an ordered list are automatically numbered by the browser."]}),e.jsxs("li",{className:"mb-2",children:[e.jsx("strong",{children:"Unordered Lists (`<ul>`)"}),": An unordered list is used when the order of items doesn’t matter. Each item in an unordered list is typically marked with a bullet point."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Description Lists (`<dl>`)"}),": A description list is used to pair terms with their descriptions. It’s commonly used for glossaries or for defining terms."]})]})]}),e.jsxs("section",{className:"mb-8",children:[e.jsxs("h2",{className:"flex items-center mb-2 text-2xl font-semibold",children:[e.jsx(c,{className:"mr-2"})," Creating an Ordered List"]}),e.jsx("p",{className:"mb-4",children:"An ordered list is created using the `<ol>` element. Each item in the list is wrapped in an `<li>` (list item) element. Here’s an example of an ordered list:"}),e.jsx(t,{code:s[0].code,language:s[0].language})]}),e.jsxs("section",{className:"mb-8",children:[e.jsxs("h2",{className:"flex items-center mb-2 text-2xl font-semibold",children:[e.jsx(i,{className:"mr-2"})," Creating an Unordered List"]}),e.jsx("p",{className:"mb-4",children:"To create an unordered list, use the `<ul>` element in combination with the `<li>` element:"}),e.jsx(t,{code:s[1].code,language:s[1].language})]}),e.jsxs("section",{className:"mb-8",children:[e.jsxs("h2",{className:"flex items-center mb-2 text-2xl font-semibold",children:[e.jsx(r,{className:"mr-2"})," Creating a Description List"]}),e.jsx("p",{className:"mb-4",children:"A description list is slightly different. It uses three tags: `<dl>`, `<dt>`, and `<dd>`. The `<dl>` element wraps the entire list, the `<dt>` element represents the term, and the `<dd>` element represents the description:"}),e.jsx(t,{code:s[2].code,language:s[2].language})]}),e.jsxs("section",{className:"mb-8",children:[e.jsxs("h2",{className:"flex items-center mb-2 text-2xl font-semibold",children:[e.jsx(n,{className:"mr-2"})," Nesting Lists"]}),e.jsx("p",{className:"mb-4",children:"HTML allows you to nest lists within each other. This can be useful for creating subcategories within a list. For example:"}),e.jsx(t,{code:s[3].code,language:s[3].language})]}),e.jsxs("section",{className:"mb-8",children:[e.jsxs("h2",{className:"flex items-center mb-2 text-2xl font-semibold",children:[e.jsx(o,{className:"mr-2"})," Attributes and Customization"]}),e.jsx("p",{className:"mb-4",children:"Lists in HTML can be customized using various attributes and CSS:"}),e.jsxs("ul",{className:"ml-6 list-disc",children:[e.jsxs("li",{className:"mb-2",children:[e.jsx("strong",{children:"Type Attribute (`type`)"}),": In ordered lists, you can specify the type of numbering (e.g., numerals, letters, or Roman numerals) using the `type` attribute."]}),e.jsxs("li",{className:"mb-2",children:[e.jsx("strong",{children:"Start Attribute (`start`)"}),": The `start` attribute can be used in an ordered list to specify the starting number."]}),e.jsx(t,{code:s[3].code,language:s[3].language}),e.jsxs("li",{children:[e.jsx("strong",{children:"Custom Bullets"}),": Unordered list bullets can be customized using CSS to change their appearance."]}),e.jsx(t,{code:s[4].code,language:s[4].language}),e.jsx(t,{code:s[5].code,language:s[5].language})]})]}),e.jsxs("section",{children:[e.jsxs("h2",{className:"flex items-center mb-2 text-2xl font-semibold",children:[e.jsx(d,{className:"mr-2"})," Best Practices for Using Lists"]}),e.jsxs("ul",{className:"ml-6 list-disc",children:[e.jsxs("li",{className:"mb-2",children:[e.jsx("strong",{children:"Use Ordered Lists for Sequential Content"}),": If the order of items matters, such as steps in a process, always use an ordered list."]}),e.jsxs("li",{className:"mb-2",children:[e.jsx("strong",{children:"Use Unordered Lists for Grouped Content"}),": For items where the sequence doesn’t matter, an unordered list is appropriate."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Avoid Over-Nesting"}),": While nesting lists is a powerful feature, excessive nesting can make the HTML code difficult to read and maintain. Keep it simple whenever possible."]})]})]})]})};export{M as default};
