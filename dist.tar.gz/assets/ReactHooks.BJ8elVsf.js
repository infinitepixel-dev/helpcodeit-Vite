import{r as t,j as e,H as n}from"./index.DQ7u83QX.js";import{H as o}from"./index.CqiazRUi.js";/* empty css                      */function i(){return t.useRef(null),t.useEffect(()=>{document.querySelectorAll("pre code").forEach(s=>{o.highlightBlock(s)})},[]),e.jsxs("div",{className:"pb-14 mx-4",children:[e.jsx(n,{title:"React Hooks",meta:[{name:"description",content:"Learn how to use React Hooks to add state and other React features to functional components."},{name:"keywords",content:"React, React Hooks, useState, useEffect, useContext, useReducer, useCallback, useMemo, useRef, custom hooks"}]}),e.jsxs("div",{className:"container",children:[e.jsx("h1",{className:"my-5 text-center text-6xl",children:"React Hooks"}),e.jsx("p",{className:"text-center",children:"Learn how to use React Hooks to add state and other React features to functional components."}),e.jsx("hr",{className:"my-4"}),e.jsxs("section",{children:[e.jsx("h2",{className:"text-4xl my-4",children:"Introduction"}),e.jsx("p",{children:"React Hooks were introduced in React 16.8 and have since become a fundamental part of writing React functional components. Hooks allow you to use state and other React features without writing a class."})]}),e.jsxs("section",{children:[e.jsx("h2",{className:"text-4xl my-4",children:"Prerequisites"}),e.jsxs("ul",{className:"list-disc list-inside",children:[e.jsx("li",{children:"Basic understanding of React and JavaScript"}),e.jsx("li",{children:"Familiarity with functional components in React"})]})]}),e.jsxs("section",{children:[e.jsx("h2",{className:"text-4xl my-4",children:"Table of Contents"}),e.jsxs("ul",{className:"list-decimal list-inside",children:[e.jsx("li",{children:e.jsx("a",{href:"#what-are-hooks",children:"What are Hooks?"})}),e.jsx("li",{children:e.jsx("a",{href:"#rules-of-hooks",children:"Rules of Hooks"})}),e.jsxs("li",{children:[e.jsx("a",{href:"#commonly-used-hooks",children:"Commonly Used Hooks"}),e.jsxs("ul",{className:"list-disc list-inside ml-6",children:[e.jsx("li",{children:e.jsx("a",{href:"#usestate",className:"text-blue-600 hover:text-blue-700 hover:underline",children:"useState"})}),e.jsx("li",{children:e.jsx("a",{href:"#useeffect",className:"text-blue-600 hover:text-blue-700 hover:underline",children:"useEffect"})}),e.jsx("li",{children:e.jsx("a",{href:"#usecontext",className:"text-blue-600 hover:text-blue-700 hover:underline",children:"useContext"})}),e.jsx("li",{children:e.jsx("a",{href:"#usereducer",className:"text-blue-600 hover:text-blue-700 hover:underline",children:"useReducer"})}),e.jsx("li",{children:e.jsx("a",{href:"#usecallback",className:"text-blue-600 hover:text-blue-700 hover:underline",children:"useCallback"})}),e.jsx("li",{children:e.jsx("a",{href:"#usememo",className:"text-blue-600 hover:text-blue-700 hover:underline",children:"useMemo"})}),e.jsx("li",{children:e.jsx("a",{href:"#useref",className:"text-blue-600 hover:text-blue-700 hover:underline",children:"useRef"})})]})]}),e.jsx("li",{children:e.jsx("a",{href:"#custom-hooks",children:"Custom Hooks"})}),e.jsx("li",{children:e.jsx("a",{href:"#conclusion",children:"Conclusion"})})]})]}),e.jsxs("section",{id:"what-are-hooks",children:[e.jsx("h2",{className:"text-4xl my-4",children:"What are Hooks?"}),e.jsx("p",{children:'Hooks are functions that let you "hook into" React state and lifecycle features from function components. They do not work inside classes — they let you use React without classes.'})]}),e.jsxs("section",{id:"rules-of-hooks",children:[e.jsx("h2",{className:"text-4xl my-4",children:"Rules of Hooks"}),e.jsxs("ul",{className:"list-disc list-inside",children:[e.jsxs("li",{children:[e.jsx("strong",{children:"Only Call Hooks at the Top Level:"})," Don’t call Hooks inside loops, conditions, or nested functions. Always use Hooks at the top level of your React function."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Only Call Hooks from React Functions:"})," Call Hooks from React function components and custom Hooks."]})]})]}),e.jsxs("section",{id:"commonly-used-hooks",children:[e.jsx("h2",{className:"text-4xl my-4",children:"Commonly Used Hooks"}),e.jsxs("section",{id:"usestate",children:[e.jsx("h3",{className:"text-3xl my-3",children:"useState"}),e.jsxs("p",{children:["The ",e.jsx("span",{className:"font-semibold italic",children:"useState"})," Hook lets you add state to functional components."]}),e.jsx("pre",{children:e.jsx("code",{className:"language-jsx",children:`import React, { useState } from 'react';

function Counter() {
  const [count, setCount] = useState(0);

  return (
    <div>
      <p>You clicked {count} times</p>
      <button onClick={() => setCount(count + 1)}>
        Click me
      </button>
    </div>
  );
}`})})]}),e.jsxs("section",{id:"useeffect",children:[e.jsx("h3",{className:"text-3xl my-3",children:"useEffect"}),e.jsxs("p",{children:["The ",e.jsx("span",{className:"font-semibold italic",children:"useEffect"})," Hook lets you perform side effects in function components. It serves the same purpose as ",e.jsx("span",{className:"font-semibold italic",children:"componentDidMount"}),", ",e.jsx("span",{className:"font-semibold italic",children:"componentDidUpdate"}),", and ",e.jsx("span",{className:"font-semibold italic",children:"componentWillUnmount"})," in React classes."]}),e.jsx("pre",{children:e.jsx("code",{className:"language-jsx",children:`import React, { useEffect, useState } from 'react';

function Example() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    document.title = \`You clicked \${count} times\`;

    return () => {
      // Clean up if needed
    };
  }, [count]);

  return (
    <div>
      <p>You clicked {count} times</p>
      <button onClick={() => setCount(count + 1)}>
        Click me
      </button>
    </div>
  );
}`})})]}),e.jsxs("section",{id:"usecontext",children:[e.jsx("h3",{className:"text-3xl my-3",children:"useContext"}),e.jsxs("p",{children:["The ",e.jsx("span",{className:"font-semibold italic",children:"useContext"}),"Hook lets you subscribe to React context without introducing nesting."]}),e.jsx("pre",{children:e.jsx("code",{className:"language-jsx",children:`import React, { useContext } from 'react';
import { MyContext } from './MyContextProvider';

function MyComponent() {
  const value = useContext(MyContext);

  return <div>{value}</div>;
}`})})]}),e.jsxs("section",{id:"usereducer",children:[e.jsx("h3",{className:"text-3xl my-3",children:"useReducer"}),e.jsxs("p",{children:["The ",e.jsx("span",{className:"font-semibold italic",children:"useReducer"})," Hook is usually preferable to ",e.jsx("span",{className:"font-semibold italic",children:"useState"})," when you have complex state logic that involves multiple sub-values or when the next state depends on the previous one."]}),e.jsx("pre",{children:e.jsx("code",{className:"language-jsx",children:`import React, { useReducer } from 'react';

const initialState = { count: 0 };

function reducer(state, action) {
  switch (action.type) {
    case 'increment':
      return { count: state.count + 1 };
    case 'decrement':
      return { count: state.count - 1 };
    default:
      throw new Error();
  }
}

function Counter() {
  const [state, dispatch] = useReducer(reducer, initialState);

  return (
    <div>
      <p>Count: {state.count}</p>
      <button onClick={() => dispatch({ type: 'increment' })}>
        +
      </button>
      <button onClick={() => dispatch({ type: 'decrement' })}>
        -
      </button>
    </div>
  );
}`})})]}),e.jsxs("section",{id:"usecallback",children:[e.jsx("h3",{className:"text-3xl my-3",children:"useCallback"}),e.jsxs("p",{children:["The ",e.jsx("span",{className:"font-semibold italic",children:"useCallback"})," Hook returns a memoized callback."]}),e.jsx("pre",{children:e.jsx("code",{className:"language-jsx",children:`import React, { useState, useCallback } from 'react';

function Parent() {
  const [count, setCount] = useState(0);

  const increment = useCallback(() => {
    setCount(c => c + 1);
  }, []);

  return <Child increment={increment} />;
}

function Child({ increment }) {
  return <button onClick={increment}>Increment</button>;
}`})})]}),e.jsxs("section",{id:"usememo",children:[e.jsx("h3",{className:"text-3xl my-3",children:"useMemo"}),e.jsxs("p",{children:["The ",e.jsx("span",{className:"font-semibold italic",children:"useMemo"})," Hook returns a memoized value."]}),e.jsx("pre",{children:e.jsx("code",{className:"language-jsx",children:`import React, { useMemo, useState } from 'react';

function Example() {
  const [count, setCount] = useState(0);

  const expensiveCalculation = (num) => {
    // Some expensive calculation
    return num;
  };

  const memoizedValue = useMemo(() => expensiveCalculation(count), [count]);

  return <div>{memoizedValue}</div>;
}`})})]}),e.jsxs("section",{id:"useref",children:[e.jsx("h3",{className:"text-3xl my-3",children:"useRef"}),e.jsxs("p",{children:["The ",e.jsx("span",{className:"font-semibold italic",children:"useRef"})," Hook lets you persist values between renders and directly access DOM elements."]}),e.jsx("pre",{children:e.jsx("code",{className:"language-jsx",children:`import React, { useRef } from 'react';

function TextInputWithFocus

Button() {
  const inputEl = useRef(null);

  const onButtonClick = () => {
    inputEl.current.focus();
  };

  return (
    <div>
      <input ref={inputEl} type="text" />
      <button onClick={onButtonClick}>Focus the input</button>
    </div>
  );
}`})})]})]}),e.jsxs("section",{id:"custom-hooks",children:[e.jsx("h2",{className:"text-4xl my-4",children:"Custom Hooks"}),e.jsx("p",{children:'You can create custom Hooks to extract and share logic between components. A custom Hook is a JavaScript function whose name starts with "use" and that may call other Hooks.'}),e.jsx("p",{children:"These are useful for situations like fetching data from an API, handling form state, or any other logic that you want to reuse across multiple components."}),e.jsx("pre",{children:e.jsx("code",{className:"language-jsx",children:`import { useState, useEffect } from 'react';

function useFetch(url) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(url)
      .then(response => response.json())
      .then(data => {
        setData(data);
        setLoading(false);
      });
  }, [url]);

  return { data, loading };
}`})})]}),e.jsxs("section",{id:"conclusion",children:[e.jsx("h2",{className:"text-4xl my-4",children:"Conclusion"}),e.jsx("p",{children:"React Hooks are a powerful addition to the React library that allow you to write cleaner, more maintainable functional components. By understanding and utilizing the built-in Hooks, as well as creating your own custom Hooks, you can enhance your React development experience."})]})]})]})}export{i as default};
