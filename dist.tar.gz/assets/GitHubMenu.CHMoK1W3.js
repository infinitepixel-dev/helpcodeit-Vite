import{j as e,L as r}from"./index.C3-FcL7I.js";import{g as n}from"./github-icon-white.DCVgM7A1.js";import"./index.D3Pu-YoY.js";import{G as c}from"./git-branch.Dy5-8jtP.js";import{G as a}from"./git-commit-horizontal.BxgHY9aE.js";import{c as t}from"./createLucideIcon.AmPkuPIc.js";import{F as h}from"./file-text.CDiR6mwP.js";/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const l=t("GitFork",[["circle",{cx:"12",cy:"18",r:"3",key:"1mpf1b"}],["circle",{cx:"6",cy:"6",r:"3",key:"1lh9wr"}],["circle",{cx:"18",cy:"6",r:"3",key:"1h7g24"}],["path",{d:"M18 9v2c0 .6-.4 1-1 1H7c-.6 0-1-.4-1-1V9",key:"1uq4wg"}],["path",{d:"M12 12v3",key:"158kv8"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=t("GitPullRequest",[["circle",{cx:"18",cy:"18",r:"3",key:"1xkwt0"}],["circle",{cx:"6",cy:"6",r:"3",key:"1lh9wr"}],["path",{d:"M13 6h3a2 2 0 0 1 2 2v7",key:"1yeb86"}],["line",{x1:"6",x2:"6",y1:"9",y2:"21",key:"rroup"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const d=t("Key",[["path",{d:"m15.5 7.5 2.3 2.3a1 1 0 0 0 1.4 0l2.1-2.1a1 1 0 0 0 0-1.4L19 4",key:"g0fldk"}],["path",{d:"m21 2-9.6 9.6",key:"1j0ho8"}],["circle",{cx:"7.5",cy:"15.5",r:"5.5",key:"yqb3hr"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const g=t("UserCheck",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["polyline",{points:"16 11 18 13 22 9",key:"1pwet4"}]]),f=()=>{const s=[{title:"Lets Setup a New Repository",path:"/githubPages/AddARepository",icon:c},{title:"I want to update code in my repository",path:"/githubPages/push",icon:a},{title:"Setting Up Authentication - Only needed the first time using GitHub on your system",path:"/githubPages/GitHubAuthentication",icon:d},{title:"Changing Your Credentials - Only when changing to a different github account",path:"/githubPages/ChangingGitHubCredentials",icon:g},{title:"Branching Guide",path:"/githubPages/GitHubBranching",icon:l},{title:"Cheatsheet of Git Commands for CLI",path:"/githubPages/GitHubCheatsheet",icon:h},{title:"Common Problems and Solutions",path:"/githubPages/GitProbAndAnswers",icon:u},{title:"Comprehensive Guide to Hosting a Project on GitHub Pages",path:"/githubPages/GitHubPagesGuide",icon:a}];return e.jsxs("div",{className:"p-4 bg-gray-800 rounded-lg shadow-md",children:[e.jsx("div",{className:"flex items-center justify-between mb-4",children:e.jsx("div",{className:"mx-auto",children:e.jsxs("h2",{className:"flex items-center text-4xl font-bold text-white",children:[e.jsx("img",{src:n,alt:"logo for github",width:50,className:"me-4"})," GitHub Navigation"]})})}),e.jsx("nav",{children:e.jsx("ul",{className:"space-y-2",children:s.map((i,o)=>e.jsx("li",{children:e.jsxs(r,{to:i.path,className:"flex px-4 py-2 text-gray-300 transition duration-500 ease-in-out rounded hover:bg-blue-800 hover:text-white",children:[e.jsx(i.icon,{className:"w-6 h-6 mr-3 text-blue-600 dark:text-blue-400"}),i.title]})},o))})})]})};export{f as default};
