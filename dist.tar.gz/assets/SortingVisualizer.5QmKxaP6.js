import{r as c,j as i}from"./index.CgC1rDly.js";const P=()=>{const[d,l]=c.useState([]),[x,u]=c.useState(!1),[p,N]=c.useState("bubble"),[I,S]=c.useState(0),[v,E]=c.useState(50),L=c.useRef(50),q=c.useRef(null),f=c.useRef(null),B=50,M=100,R={bubble:`function bubbleSort(arr) {
  const n = arr.length;
  for (let i = 0; i < n - 1; i++) {
    for (let j = 0; j < n - i - 1; j++) {
      if (arr[j] > arr[j + 1]) {
        [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
      }
    }
  }
  return arr;
}`,selection:`function selectionSort(arr) {
  const n = arr.length;
  for (let i = 0; i < n - 1; i++) {
    let minIndex = i;
    for (let j = i + 1; j < n; j++) {
      if (arr[j] < arr[minIndex]) {
        minIndex = j;
      }
    }
    if (minIndex !== i) {
      [arr[i], arr[minIndex]] = [arr[minIndex], arr[i]];
    }
  }
  return arr;
}`,insertion:`function insertionSort(arr) {
  const n = arr.length;
  for (let i = 1; i < n; i++) {
    let key = arr[i];
    let j = i - 1;
    while (j >= 0 && arr[j] > key) {
      arr[j + 1] = arr[j];
      j--;
    }
    arr[j + 1] = key;
  }
  return arr;
}`,quick:`function quickSort(arr, start = 0, end = arr.length - 1) {
  if (start >= end) return;

  let pivotIndex = partition(arr, start, end);
  quickSort(arr, start, pivotIndex - 1);
  quickSort(arr, pivotIndex + 1, end);

  return arr;
}

function partition(arr, start, end) {
  const pivot = arr[end];
  let i = start - 1;

  for (let j = start; j < end; j++) {
    if (arr[j] < pivot) {
      i++;
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
  }

  [arr[i + 1], arr[end]] = [arr[end], arr[i + 1]];
  return i + 1;
}`,merge:`function mergeSort(arr, start = 0, end = arr.length - 1) {
  if (start >= end) return;

  const mid = Math.floor((start + end) / 2);
  mergeSort(arr, start, mid);
  mergeSort(arr, mid + 1, end);
  merge(arr, start, mid, end);

  return arr;
}

function merge(arr, start, mid, end) {
  const leftArray = arr.slice(start, mid + 1);
  const rightArray = arr.slice(mid + 1, end + 1);
  let i = 0, j = 0, k = start;

  while (i < leftArray.length && j < rightArray.length) {
    if (leftArray[i] <= rightArray[j]) {
      arr[k] = leftArray[i];
      i++;
    } else {
      arr[k] = rightArray[j];
      j++;
    }
    k++;
  }

  while (i < leftArray.length) {
    arr[k] = leftArray[i];
    i++;
    k++;
  }

  while (j < rightArray.length) {
    arr[k] = rightArray[j];
    j++;
    k++;
  }
}`},z={bubble:"Bubble Sort repeatedly steps through the list, compares adjacent elements and swaps them if they are in the wrong order. The pass through the list is repeated until the list is sorted.",selection:"Selection Sort divides the input list into two parts: a sorted portion at the left end and an unsorted portion at the right end. It repeatedly selects the smallest element from the unsorted portion and moves it to the sorted portion.",insertion:"Insertion Sort builds the final sorted array one item at a time. It iterates through an input array and removes one element per iteration, finds the place the element belongs in the sorted list and inserts it there.",quick:"Quick Sort picks an element as pivot and partitions the given array around the picked pivot. It then recursively sorts the sub-arrays on the left and right of the pivot.",merge:"Merge Sort divides the unsorted list into n sublists, each containing one element (a list of one element is considered sorted). Then repeatedly merge sublists to produce new sorted sublists until there is only one sublist remaining."};c.useEffect(()=>{A()},[]),c.useEffect(()=>{T(p)},[p]),c.useEffect(()=>{L.current=v},[v]);const A=()=>{const e=Array.from({length:B},()=>Math.floor(Math.random()*M)+1);l(e),S(0)},T=e=>{const t=R[e];f.current&&(f.current.innerHTML=t.split(`
`).map((r,s)=>`<span class="code-line" data-line="${s}">${r}</span>`).join(`
`))},h=e=>{f.current.querySelectorAll(".code-line").forEach(s=>s.classList.remove("active"));const r=f.current.querySelector(`.code-line[data-line="${e}"]`);r&&r.classList.add("active")},b=()=>{S(e=>e+1)},y=e=>new Promise(t=>setTimeout(t,e)),j=()=>500-L.current*4.99,$=async()=>{const e=d.length;let t=[...d];for(let r=0;r<e-1;r++){for(let a=0;a<e-r-1;a++){h(3);const n=document.getElementsByClassName("array-bar");n[a].classList.add("comparing"),n[a+1].classList.add("comparing-against"),b(),t[a]>t[a+1]&&(h(5),[t[a],t[a+1]]=[t[a+1],t[a]],l([...t])),await y(Math.max(1,j())),n[a].classList.remove("comparing"),n[a+1].classList.remove("comparing-against")}document.getElementsByClassName("array-bar")[e-r-1].classList.add("sorted")}u(!1)},V=async()=>{const e=d.length;let t=[...d];for(let r=0;r<e-1;r++){let s=r;for(let n=r+1;n<e;n++){h(3);const o=document.getElementsByClassName("array-bar");o[n].classList.add("comparing"),o[s].classList.add("comparing-against"),b(),t[n]<t[s]&&(h(5),s=n),await y(j()),o[n].classList.remove("comparing"),o[s].classList.remove("comparing-against")}s!==r&&([t[r],t[s]]=[t[s],t[r]],l([...t])),document.getElementsByClassName("array-bar")[r].classList.add("sorted")}u(!1)},Q=async()=>{const e=d.length;let t=[...d];for(let r=1;r<e;r++){let s=t[r],a=r-1;for(;a>=0&&t[a]>s;){h(5);const o=document.getElementsByClassName("array-bar");o[a].classList.add("comparing"),o[a+1].classList.add("comparing-against"),b(),t[a+1]=t[a],l([...t]),await y(j()),o[a].classList.remove("comparing"),o[a+1].classList.remove("comparing-against"),a--}t[a+1]=s,l([...t]),document.getElementsByClassName("array-bar")[r].classList.add("sorted")}u(!1)},w=async(e,t=0,r=e.length-1)=>{if(t>=r)return;let s=await D(e,t,r);await w(e,t,s-1),await w(e,s+1,r),l([...e]),u(!1)},D=async(e,t,r)=>{const s=e[r];let a=t-1;for(let n=t;n<r;n++){h(5);const o=document.getElementsByClassName("array-bar");o[n].classList.add("comparing"),o[r].classList.add("comparing-against"),b(),e[n]<s&&(a++,[e[a],e[n]]=[e[n],e[a]],l([...e])),await y(j()),o[n].classList.remove("comparing"),o[r].classList.remove("comparing-against")}return[e[a+1],e[r]]=[e[r],e[a+1]],l([...e]),a+1},k=async(e,t=0,r=e.length-1)=>{if(t>=r)return;const s=Math.floor((t+r)/2);await k(e,t,s),await k(e,s+1,r),await F(e,t,s,r),l([...e]),u(!1)},F=async(e,t,r,s)=>{const a=e.slice(t,r+1),n=e.slice(r+1,s+1);let o=0,g=0,m=t;for(;o<a.length&&g<n.length;){h(5);const C=document.getElementsByClassName("array-bar");C[m].classList.add("comparing"),b(),a[o]<=n[g]?(e[m]=a[o],o++):(e[m]=n[g],g++),l([...e]),await y(j()),C[m].classList.remove("comparing"),m++}for(;o<a.length;)e[m]=a[o],o++,m++;for(;g<n.length;)e[m]=n[g],g++,m++;l([...e])},G=async()=>{switch(u(!0),S(0),p){case"bubble":await $();break;case"selection":await V();break;case"insertion":await Q();break;case"quick":await w(d);break;case"merge":await k(d);break}u(!1)};return i.jsxs("div",{className:"mb-10 sorting-visualizer",children:[i.jsxs("div",{className:"grid justify-center mb-5",children:[i.jsx("h1",{className:"my-5 text-3xl",children:"Sorting Algorithms Visualization"}),i.jsxs("div",{className:"p-5 bg-gray-600 rounded-md controls",children:[i.jsx("button",{onClick:A,disabled:x,className:"p-1 mr-4 bg-blue-600 rounded hover:bg-blue-800",children:"Generate New Array"}),i.jsxs("select",{className:"text-black",value:p,onChange:e=>N(e.target.value),disabled:x,children:[i.jsx("option",{value:"bubble",children:"Bubble Sort"}),i.jsx("option",{value:"selection",children:"Selection Sort"}),i.jsx("option",{value:"insertion",children:"Insertion Sort"}),i.jsx("option",{value:"quick",children:"Quick Sort"}),i.jsx("option",{value:"merge",children:"Merge Sort"})]}),i.jsx("button",{onClick:G,disabled:x,className:"p-1 bg-blue-600 rounded ms-4 hover:bg-blue-800",children:"Start Sorting"})]}),i.jsxs("div",{className:"speed-control",children:[i.jsx("label",{htmlFor:"speedSlider",children:"Speed:"}),i.jsx("input",{type:"range",id:"speedSlider",min:"1",max:"100",value:v,onChange:e=>E(Number(e.target.value))}),i.jsxs("span",{children:[v,"%"]})]})]}),i.jsx("div",{id:"algorithmExplanation",children:z[p]}),i.jsx("div",{className:"grid justify-center my-5 text-3xl font-bold",children:i.jsxs("div",{id:"iterationCount",children:["Iterations: ",I]})}),i.jsxs("div",{className:"visualization-container",children:[i.jsx("div",{id:"arrayContainer",ref:q,children:d.map((e,t)=>i.jsx("div",{className:"array-bar",style:{height:`${e*3}px`}},t))}),i.jsx("pre",{id:"codeContainer",children:i.jsx("code",{ref:f})})]})]})};export{P as default};
