const s="/assets/React.C5UGUe3r.svg";export{s as r};
