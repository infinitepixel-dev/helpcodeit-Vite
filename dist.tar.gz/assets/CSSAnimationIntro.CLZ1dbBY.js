import{j as e}from"./index.D2dmul_t.js";import n from"./CodeBlock.DcpLYaKa.js";import"./ext-beautify.moJIAcHp.js";import"./CopyButton.wsQw8STc.js";const o=()=>e.jsxs("div",{className:"max-w-3xl p-6 mx-auto",children:[e.jsx("h1",{className:"mb-4 text-2xl font-semibold",children:"Introduction to CSS Animations"}),e.jsx("p",{className:"mb-4",children:"CSS animations allow you to add visual effects to HTML elements without needing to rely on JavaScript. With animations, you can change the style of an element over time, such as moving it, changing its size, rotating it, or fading it in or out. These animations can enhance the user experience by making web pages feel more dynamic and interactive."}),e.jsx("h2",{className:"mb-2 text-xl font-semibold",children:"Key Concepts"}),e.jsxs("ol",{className:"pl-5 mb-4 list-decimal",children:[e.jsxs("li",{className:"mb-2",children:[e.jsx("strong",{children:"Keyframes:"}),e.jsx("br",{}),"Keyframes define the start and end points of an animation, along with possible intermediate waypoints. They are created using the ",e.jsx("code",{className:"px-1 rounded",children:"@keyframes"})," rule, where you specify what should happen at specific points during the animation."]}),e.jsxs("li",{className:"mb-2",children:[e.jsx("strong",{children:"Animation Properties:"}),e.jsx("br",{}),e.jsxs("ul",{className:"pl-5 list-disc",children:[e.jsxs("li",{children:[e.jsx("strong",{children:"animation-name"}),": Specifies the name of the ",e.jsx("code",{className:"px-1 rounded",children:"@keyframes"})," animation."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"animation-duration"}),": Defines how long the animation should take to complete one cycle."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"animation-timing-function"}),": Controls the speed of the animation (e.g., ease, linear, ease-in, ease-out)."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"animation-delay"}),": Specifies a delay before the animation starts."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"animation-iteration-count"}),": Defines how many times the animation should repeat (e.g., ",e.jsx("code",{className:"px-1 rounded",children:"infinite"})," for continuous repetition)."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"animation-direction"}),": Determines whether the animation should reverse direction on each cycle (",e.jsx("code",{className:"px-1 rounded",children:"normal"}),", ",e.jsx("code",{className:"px-1 rounded",children:"reverse"}),", ",e.jsx("code",{className:"px-1 rounded",children:"alternate"}),")."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"animation-fill-mode"}),": Dictates what styles should be applied to the element before the animation starts and after it ends."]})]})]})]}),e.jsx("h2",{className:"mb-2 text-xl font-semibold",children:"Basic Example"}),e.jsx("p",{className:"mb-4",children:"Let’s look at a simple example of a CSS animation that changes the color of a box from red to blue."}),e.jsx(n,{code:`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSS Animation Example</title>
    <style>
        /* Define the animation keyframes */
        @keyframes colorChange {
            0% { background-color: red; }
            100% { background-color: blue; }
        }

        /* Apply the animation to the element */
        .animated-box {
            width: 100px;
            height: 100px;
            background-color: red;
            animation-name: colorChange;
            animation-duration: 2s;
            animation-timing-function: ease-in-out;
            animation-iteration-count: infinite;
        }
    </style>
</head>
<body>
    <div class="animated-box"></div>
</body>
</html>`,language:"html"}),e.jsx("h2",{className:"mb-2 text-xl font-semibold",children:"Live Example"}),e.jsx("p",{className:"mb-4",children:"Here's a visual representation of the animation described in the code above:"}),e.jsx("div",{className:"flex items-center justify-center mb-6",children:e.jsx("div",{className:"w-24 h-24 animated-box",style:{animation:"colorChange 2s ease-in-out infinite"}})}),e.jsx("style",{jsx:!0,children:`
        @keyframes colorChange {
          0% { background-color: red; }
          100% { background-color: blue; }
        }
        .animated-box {
          background-color: red;
        }
      `}),e.jsx("h2",{className:"mb-2 text-xl font-semibold",children:"How It Works"}),e.jsxs("ul",{className:"pl-5 mb-4 list-disc",children:[e.jsxs("li",{children:[e.jsx("strong",{children:"Keyframes:"})," The ",e.jsx("code",{className:"px-1 rounded",children:"@keyframes colorChange"})," defines an animation that starts with a red background at 0% (the beginning) and ends with a blue background at 100% (the end)."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Animation Properties:"}),e.jsxs("ul",{className:"pl-5 list-disc",children:[e.jsxs("li",{children:["The ",e.jsx("code",{className:"px-1 rounded",children:"animation-name: colorChange;"})," links the defined keyframes to the ",e.jsx("code",{className:"px-1 rounded",children:".animated-box"})," element."]}),e.jsxs("li",{children:[e.jsx("code",{className:"px-1 rounded",children:"animation-duration: 2s;"})," sets the animation to run over 2 seconds."]}),e.jsxs("li",{children:[e.jsx("code",{className:"px-1 rounded",children:"animation-timing-function: ease-in-out;"})," makes the animation speed up at the start and slow down at the end."]}),e.jsxs("li",{children:[e.jsx("code",{className:"px-1 rounded",children:"animation-iteration-count: infinite;"})," ensures the animation will keep repeating indefinitely."]})]})]})]}),e.jsx("h2",{className:"mb-2 text-xl font-semibold",children:"Advanced Animations"}),e.jsx("p",{className:"mb-4",children:"You can create more complex animations by:"}),e.jsxs("ul",{className:"pl-5 mb-4 list-disc",children:[e.jsx("li",{children:"Using multiple keyframes (e.g., 0%, 50%, 100%) to define more steps."}),e.jsxs("li",{children:["Combining multiple animations on a single element using the ",e.jsx("code",{className:"px-1 rounded",children:"animation"})," shorthand property."]}),e.jsx("li",{children:"Adjusting the animation’s direction and fill mode for different effects."})]}),e.jsx("h2",{className:"mb-2 text-xl font-semibold",children:"Shorthand Property"}),e.jsxs("p",{className:"mb-4",children:["You can use the ",e.jsx("code",{className:"px-1 rounded",children:"animation"})," shorthand to define all the animation properties in one line:"]}),e.jsx(n,{code:`.animated-box {
    animation: colorChange 2s ease-in-out infinite;
}`,language:"css"}),e.jsx("h2",{className:"mb-4 text-xl font-semibold",children:"Live Example"}),e.jsx("div",{className:"flex items-center justify-center mb-6",children:e.jsx("div",{className:"w-24 h-24 rounded-lg shadow-md",style:{animation:"colorChange 2s ease-in-out infinite"}})}),e.jsx("style",{jsx:!0,children:`
        @keyframes colorChange {
          0% { background-color: red; }
          100% { background-color: blue; }
        }
      `}),e.jsx("p",{className:"mb-4",children:"This box demonstrates the color change animation described above. It smoothly transitions from red to blue and back, repeating indefinitely."}),e.jsx("h2",{className:"mb-2 text-xl font-semibold",children:"Transform Property"}),e.jsxs("p",{className:"mb-4",children:["The CSS ",e.jsx("code",{className:"px-1 rounded",children:"transform"})," property allows you to modify the coordinate space of the CSS visual formatting model. When combined with animations, it can create powerful visual effects."]}),e.jsx("h3",{className:"mb-2 text-lg font-semibold",children:"Common Transform Functions"}),e.jsxs("ul",{className:"pl-5 mb-4 list-disc",children:[e.jsxs("li",{children:[e.jsx("code",{className:"px-1 rounded",children:"translate(x, y)"}),": Moves an element along the X and Y axes"]}),e.jsxs("li",{children:[e.jsx("code",{className:"px-1 rounded",children:"rotate(angle)"}),": Rotates an element around a fixed point"]}),e.jsxs("li",{children:[e.jsx("code",{className:"px-1 rounded",children:"scale(x, y)"}),": Resizes an element"]}),e.jsxs("li",{children:[e.jsx("code",{className:"px-1 rounded",children:"skew(x-angle, y-angle)"}),": Skews an element along the X and Y axes"]})]}),e.jsx("h3",{className:"mb-2 text-lg font-semibold",children:"Example: Rotating Box"}),e.jsx(n,{code:`@keyframes rotate {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

.rotating-box {
  width: 100px;
  height: 100px;
  background-color: #3498db;
  animation: rotate 3s linear infinite;
}`,language:"css"}),e.jsx("div",{className:"flex items-center justify-center mb-6",children:e.jsx("div",{className:"w-24 h-24 bg-blue-500",style:{animation:"rotate 3s linear infinite"}})}),e.jsx("style",{jsx:!0,children:`
        @keyframes rotate {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}),e.jsx("p",{className:"mb-4",children:"This example demonstrates a box rotating 360 degrees continuously. The transform property is animated to create a smooth rotation effect."}),e.jsx("h3",{className:"mb-2 text-lg font-semibold",children:"Combining Transforms"}),e.jsx("p",{className:"mb-4",children:"You can combine multiple transform functions to create more complex animations:"}),e.jsx(n,{code:`@keyframes complex-move {
  0% { transform: translateX(0) rotate(0deg) scale(1); }
  50% { transform: translateX(100px) rotate(180deg) scale(1.5); }
  100% { transform: translateX(0) rotate(360deg) scale(1); }
}

.complex-box {
  width: 50px;
  height: 50px;
  background-color: #e74c3c;
  animation: complex-move 4s ease-in-out infinite;
}`,language:"css"}),e.jsx("div",{className:"flex items-center justify-center mb-6",children:e.jsx("div",{className:"w-12 h-12 bg-red-500",style:{animation:"complex-move 4s ease-in-out infinite"}})}),e.jsx("style",{jsx:!0,children:`
        @keyframes complex-move {
          0% { transform: translateX(0) rotate(0deg) scale(1); }
          50% { transform: translateX(100px) rotate(180deg) scale(1.5); }
          100% { transform: translateX(0) rotate(360deg) scale(1); }
        }
      `}),e.jsx("p",{className:"mb-4",children:"This more advanced example combines translation, rotation, and scaling in a single animation. Experiment with different combinations to create unique effects!"}),e.jsx("h2",{className:"mb-2 text-xl font-semibold",children:"Conclusion"}),e.jsx("p",{children:"CSS animations are a powerful tool for creating engaging and dynamic web content. By mastering keyframes and animation properties, you can enhance the user experience on your website with smooth, visually appealing effects. Start experimenting with different animations to see how they can transform your designs!"})]});export{o as default};
