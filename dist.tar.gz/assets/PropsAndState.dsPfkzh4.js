import{r,j as e,H as p,L as m}from"./index.CgC1rDly.js";import{H as h}from"./index.EJlGeBp8.js";/* empty css                      */const P=()=>{const t=r.useRef(null),[c,l]=r.useState(0);return r.useEffect(()=>{const s=new IntersectionObserver(a=>{a.forEach((n,i)=>{if(n.isIntersecting){const d=`${i*.2}s`;n.target.style.animationDelay=d,n.target.classList.add("animate-fadeIn")}else n.target.style.animationDelay="0s",n.target.classList.remove("animate-fadeIn")})},{rootMargin:"0px",threshold:.1}),o=document.querySelectorAll(".observeMe");return o.forEach(a=>s.observe(a)),()=>o.forEach(a=>s.unobserve(a))},[]),r.useEffect(()=>{document.querySelectorAll("pre code").forEach(s=>{h.highlightBlock(s)})},[]),e.jsxs("div",{className:"roboto-font container mx-auto p-2 px-4 text-xl sm:p-8",children:[e.jsxs(p,{children:[e.jsx("title",{children:"Comprehensive Guide to Props and State in React | Help Code It"}),e.jsx("meta",{name:"description",content:"An in-depth exploration of Props and State in React. Learn about different types of props, how to use state in class and functional components, and best practices for both."}),e.jsx("link",{rel:"canonical",href:"https://www.helpcodeit.com/react/props-and-state-guide"}),e.jsx("meta",{name:"robots",content:"index, follow"}),e.jsx("meta",{name:"keywords",content:"React, props, state, components, web development, JavaScript, useState, this.state"})]}),e.jsxs("div",{className:"flex flex-col",children:[e.jsxs("div",{className:"observeMe",children:[e.jsx("h1",{className:"my-20 text-center text-5xl",children:"Comprehensive Guide to Props and State in React"}),e.jsx("hr",{className:"border-2 border-black dark:border-white"})]}),e.jsxs("div",{className:"observeMe",children:[e.jsx("h2",{className:"mt-10 text-4xl",children:"Introduction"}),e.jsx("p",{className:"mb-10 text-2xl",children:"Props and State are fundamental concepts in React that govern how data is managed and passed between components. While they serve different purposes, understanding both is crucial for building dynamic and interactive React applications."}),e.jsx("hr",{className:"mb-10 border-2 border-black dark:border-white"})]}),e.jsxs("div",{className:"observeMe",children:[e.jsx("h2",{className:"mt-10 text-4xl",children:"Part 1: Props in React"}),e.jsx("p",{className:"mb-10 text-2xl",children:"Props (short for properties) are a way to pass data from parent to child components in React. They are read-only and help make your components reusable and dynamic."}),e.jsx("h3",{className:"mt-5 text-3xl",children:"Types of Props"}),e.jsx("h4",{className:"mt-5 text-2xl",children:"1. Primitive Props"}),e.jsx("p",{className:"mb-5 text-xl",children:"These include strings, numbers, and booleans."}),e.jsx("pre",{className:"my-5",children:e.jsx("code",{ref:t,className:"language-javascript",children:`
function UserProfile(props) {
  return (
    <div>
      <h1>{props.name}</h1>
      <p>Age: {props.age}</p>
      <p>Is Admin: {props.isAdmin ? 'Yes' : 'No'}</p>
    </div>
  );
}

// Usage
<UserProfile name="Alice" age={30} isAdmin={true} />
  `})}),e.jsx("h4",{className:"mt-5 text-2xl",children:"2. Object Props"}),e.jsx("p",{className:"mb-5 text-xl",children:"Passing entire objects as props is useful for grouping related data."}),e.jsx("pre",{className:"my-5",children:e.jsx("code",{ref:t,className:"language-javascript",children:`
function ProductCard({ product }) {
  return (
    <div>
      <h2>{product.name}</h2>
      <p>Price:{product.price}</p>
      <p>Category:{product.category}</p>
    </div>
  );
}

// Usage
const product = { name: 'Laptop', price: 999.99, category: 'Electronics' };
<ProductCard product={product} />
  `})}),e.jsx("h4",{className:"mt-5 text-2xl",children:"3. Function Props"}),e.jsx("p",{className:"mb-5 text-xl",children:"Functions can be passed as props, allowing child components to communicate with their parents."}),e.jsx("pre",{className:"my-5",children:e.jsx("code",{ref:t,className:"language-javascript",children:`
function Button({ label, onClick }) {
  return (
    <button onClick={onClick}>
      {label}
    </button>
  );
}

// Usage
function handleClick() {
  alert('Button clicked!');
}
<Button label="Click me" onClick={handleClick} />
  `})}),e.jsx("h4",{className:"mt-5 text-2xl",children:"4. Children Props"}),e.jsx("p",{className:"mb-5 text-xl",children:"The special 'children' prop allows for component composition."}),e.jsx("pre",{className:"my-5",children:e.jsx("code",{ref:t,className:"language-javascript",children:`
function Card({ children, title }) {
  return (
    <div className="card">
      <h2>{title}</h2>
      {children}
    </div>
  );
}

// Usage
<Card title="Welcome">
  <p>This is the content of the card.</p>
  <button>Learn More</button>
</Card>
  `})}),e.jsx("h3",{className:"mt-10 text-3xl",children:"Best Practices for Props"}),e.jsxs("ul",{className:"mb-10 list-disc pl-5 text-xl",children:[e.jsx("li",{children:"Use descriptive names for props"}),e.jsx("li",{children:"Provide default values for optional props"}),e.jsx("li",{children:"Use PropTypes or TypeScript for type checking"}),e.jsx("li",{children:"Treat props as read-only; never modify them directly"}),e.jsx("li",{children:"Use the spread operator for passing multiple props"})]}),e.jsx("hr",{className:"mb-10 border-2 border-black dark:border-white"})]}),e.jsxs("div",{className:"observeMe",children:[e.jsx("h2",{className:"mt-10 text-4xl",children:"Part 2: State in React"}),e.jsx("p",{className:"mb-10 text-2xl",children:"State is a way for a component to maintain and update its own data. Unlike props, state can be changed using setState (in class components) or useState (in functional components)."}),e.jsx("h3",{className:"mt-5 text-3xl",children:"State in Class Components"}),e.jsx("p",{className:"mb-5 text-xl",children:"In class components, state is defined in the constructor and updated using this.setState()."}),e.jsx("pre",{className:"my-5",children:e.jsx("code",{ref:t,className:"language-javascript",children:`
class Counter extends React.Component {
  constructor(props) {
    super(props);
    this.state = { count: 0 };
  }

  increment = () => {
    this.setState(prevState => ({ count: prevState.count + 1 }));
  }

  render() {
    return (
      <div>
        <p>Count: {this.state.count}</p>
        <button onClick={this.increment}>Increment</button>
      </div>
    );
  }
}
  `})}),e.jsx("h3",{className:"mt-10 text-3xl",children:"State in Functional Components"}),e.jsx("p",{className:"mb-5 text-xl",children:"In functional components, we use the useState hook to manage state."}),e.jsx("pre",{className:"my-5",children:e.jsx("code",{ref:t,className:"language-javascript",children:`
function Counter() {
  const [count, setCount] = useState(0);

  const increment = () => {
    setCount(prevCount => prevCount + 1);
  };

  return (
    <div>
      <p>Count: {count}</p>
      <button onClick={increment}>Increment</button>
    </div>
  );
}
  `})}),e.jsx("h3",{className:"mt-10 text-3xl",children:"Complex State Management"}),e.jsx("p",{className:"mb-5 text-xl",children:"For more complex state, you can use objects or multiple state variables."}),e.jsx("pre",{className:"my-5",children:e.jsx("code",{ref:t,className:"language-javascript",children:`
function UserForm() {
  const [user, setUser] = useState({ name: '', email: '', age: '' });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser(prevUser => ({
      ...prevUser,
      [name]: value
    }));
  };

  return (
    <form>
      <input
        name="name"
        value={user.name}
        onChange={handleChange}
        placeholder="Name"
      />
      <input
        name="email"
        value={user.email}
        onChange={handleChange}
        placeholder="Email"
      />
      <input
        name="age"
        value={user.age}
        onChange={handleChange}
        placeholder="Age"
      />
    </form>
  );
}
  `})}),e.jsx("h3",{className:"mt-10 text-3xl",children:"Best Practices for State"}),e.jsxs("ul",{className:"mb-10 list-disc pl-5 text-xl",children:[e.jsx("li",{children:"Keep state as local as possible"}),e.jsx("li",{children:"Don't update state directly; always use setState or the state updater function"}),e.jsx("li",{children:"State updates may be asynchronous; don't rely on their values for calculating the next state"}),e.jsx("li",{children:"Lift state up to common ancestors when multiple components need to share state"}),e.jsx("li",{children:"Use the useReducer hook for complex state logic"})]}),e.jsx("hr",{className:"mb-10 border-2 border-black dark:border-white"})]}),e.jsxs("div",{className:"observeMe",children:[e.jsx("h2",{className:"mt-10 text-4xl",children:"Props vs State: Key Differences"}),e.jsxs("ul",{className:"mb-10 list-disc pl-5 text-xl",children:[e.jsx("li",{children:"Props are passed from parent to child; state is managed within a component"}),e.jsx("li",{children:"Props are read-only; state can be updated"}),e.jsx("li",{children:"Props can be used to configure a component; state represents mutable data that changes over time"}),e.jsx("li",{children:"Changes in props come from outside the component; changes in state are made inside the component"}),e.jsx("li",{children:"Props help with component reusability; state is for handling user interactions and dynamic data"})]})]}),e.jsxs("div",{className:"observeMe",children:[e.jsx("h2",{className:"mt-10 text-4xl",children:"Live Example: State in Action"}),e.jsx("p",{className:"mb-5 text-2xl",children:"Here's a live example of state. Click the button to increment the count:"}),e.jsxs("div",{className:"mb-10 rounded-lg border-2 border-gray-300 p-5",children:[e.jsxs("p",{className:"mb-3 text-3xl",children:["Count: ",c]}),e.jsx("button",{onClick:()=>l(s=>s+1),className:"rounded bg-blue-500 px-4 py-2 font-bold text-white hover:bg-blue-700","aria-label":"Increment count by 1",children:"Increment"})]})]}),e.jsxs("div",{className:"observeMe",children:[e.jsx("h2",{className:"mt-10 text-4xl",children:"Conclusion"}),e.jsx("p",{className:"mb-10 mt-5 text-2xl",children:"Understanding the differences and use cases for props and state is crucial for building efficient React applications. Props allow you to create reusable, configurable components, while state enables you to create dynamic, interactive UIs. By mastering both concepts, you'll be well-equipped to tackle complex React projects."})]}),e.jsx("div",{className:"pb-10 text-center text-2xl text-red-500 dark:text-white",children:e.jsx(m,{to:"/ReactMain",children:"Back to React Main Page"})})]})]})};export{P as default};
